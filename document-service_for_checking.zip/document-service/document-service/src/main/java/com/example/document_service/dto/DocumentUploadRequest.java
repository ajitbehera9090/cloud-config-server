package com.example.document_service.dto;

import com.example.document_service.entity.DocumentType;
import com.example.document_service.entity.ReferenceType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentUploadRequest {

    @NotNull(message = "Reference type is required")
    private ReferenceType referenceType;

    @NotNull(message = "Reference id is required")
    private Long referenceId;

    @NotNull(message = "Document type is required")
    private DocumentType documentType;

    @NotBlank(message = "Original file name is required")
    private String originalFileName;

}