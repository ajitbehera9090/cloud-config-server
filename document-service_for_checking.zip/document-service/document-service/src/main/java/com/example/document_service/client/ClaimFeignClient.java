package com.example.document_service.client;


import com.example.document_service.dto.ClaimDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "CLAIM-SERVICE")
public interface ClaimFeignClient {

    @GetMapping("/claims/{claimId}")
    ClaimDTO getClaimById(
            @PathVariable Long claimId);

}