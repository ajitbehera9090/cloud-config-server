package com.example.document_service.dto;

import com.example.document_service.entity.DocumentStatus;
import com.example.document_service.entity.DocumentType;
import com.example.document_service.entity.GeneratedBy;
import com.example.document_service.entity.ReferenceType;
import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentDTO {

    private Long documentId;

    private ReferenceType referenceType;

    private Long referenceId;

    private DocumentType documentType;

    private String originalFileName;

    private String storedFileName;

    private String storagePath;

    private String contentType;

    private Long fileSize;

    private String checksum;

    private Integer version;

    private GeneratedBy generatedBy;

    private DocumentStatus status;

    private Boolean deleted;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

}