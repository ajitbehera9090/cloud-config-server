package com.example.document_service.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentDTO {

    private Long paymentId;

    private Long policyId;

    private Long customerId;

    private String customerName;

    private BigDecimal amount;

    private String paymentMethod;

    private String transactionId;

    private LocalDate paymentDate;

}