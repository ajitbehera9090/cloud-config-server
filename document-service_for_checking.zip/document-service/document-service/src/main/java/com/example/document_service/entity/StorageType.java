package com.example.document_service.entity;

public enum StorageType {

    LOCAL,

    AWS_S3,

    AZURE_BLOB,

    GOOGLE_CLOUD_STORAGE
}