package com.example.document_service.entity;

public enum DocumentType {

    POLICY_CERTIFICATE,

    PAYMENT_RECEIPT,

    CLAIM_ACKNOWLEDGEMENT,

    CLAIM_APPROVAL,

    CLAIM_REJECTION,

    RENEWAL_CERTIFICATE,

    WELCOME_LETTER

}