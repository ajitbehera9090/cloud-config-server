package com.example.document_service.service;


import com.example.document_service.dto.*;
import com.example.document_service.entity.*;
import com.example.document_service.exception.DocumentNotFoundException;
import com.example.document_service.generator.ClaimPdfGenerator;
import com.example.document_service.generator.PaymentPdfGenerator;
import com.example.document_service.generator.PolicyPdfGenerator;

import com.example.document_service.mapper.DocumentMapper;
import com.example.document_service.repository.DocumentRepository;

import com.example.document_service.util.DocumentMetadataUtil;
import lombok.RequiredArgsConstructor;

import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

    private final DocumentRepository documentRepository;

    private final DocumentMapper documentMapper;

    private final StorageService storageService;

    private final PolicyPdfGenerator policyPdfGenerator;

    private final ClaimPdfGenerator claimPdfGenerator;

    private final PaymentPdfGenerator paymentPdfGenerator;

    private final DocumentMetadataUtil metadataUtil;

    /**
     * Find document by id.
     */
    private Document findDocument(Long documentId) {

        return documentRepository
                .findByDocumentIdAndDeletedFalse(documentId)
                .orElseThrow(() ->
                        new DocumentNotFoundException(
                                "Document not found with id : " + documentId
                        ));

    }

    @Override
    public DocumentDTO uploadDocument(DocumentUploadRequest request,
                                      MultipartFile file)
            throws IOException {

        String storedFileName =
                metadataUtil.generateStoredFileName(
                        file.getOriginalFilename()
                );

        String storagePath =
                storageService.store(file, storedFileName);

        Document document =
                metadataUtil.buildDocument(
                        request,
                        storedFileName,
                        storagePath,
                        file.getContentType(),
                        file.getSize()
                );

        document = documentRepository.save(document);

        return documentMapper.toDTO(document);

    }

    @Override
    public Resource downloadDocument(Long documentId) {

        Document document = findDocument(documentId);

        return storageService.load(
                document.getStoredFileName()
        );

    }

    @Override
    public DocumentDTO getDocumentById(Long documentId) {

        return documentMapper.toDTO(findDocument(documentId));

    }

    @Override
    public List<DocumentDTO> getDocumentsByCustomer(Long customerId) {

        return getDocumentsByReference(ReferenceType.CUSTOMER, customerId);

    }

    @Override
    public List<DocumentDTO> getDocumentsByPolicy(Long policyId) {

        return getDocumentsByReference(ReferenceType.POLICY, policyId);

    }

    @Override
    public List<DocumentDTO> getDocumentsByClaim(Long claimId) {

        return getDocumentsByReference(ReferenceType.CLAIM, claimId);

    }

    @Override
    public List<DocumentDTO> getAllDocuments() {

        return documentRepository
                .findByDeletedFalse()
                .stream()
                .map(documentMapper::toDTO)
                .collect(Collectors.toList());

    }

    @Override
    public List<DocumentDTO> getDocumentsByReference(
            ReferenceType referenceType,
            Long referenceId) {

        return documentRepository
                .findByReferenceTypeAndReferenceIdAndDeletedFalse(
                        referenceType,
                        referenceId
                )
                .stream()
                .map(documentMapper::toDTO)
                .toList();
    }

    @Override
    public void deleteDocument(Long documentId) throws IOException {

        Document document = findDocument(documentId);

        storageService.delete(
                document.getStoredFileName()
        );

        document.setDeleted(true);

        documentRepository.save(document);
    }

    @Override
    public DocumentDTO generatePolicyDocument(PolicyDTO policyDTO)
            throws IOException {

        byte[] pdfContent =
                policyPdfGenerator.generate(policyDTO);

        String fileName =
                "POLICY_" +
                        policyDTO.getPolicyId() +
                        ".pdf";

        String storedFileName =
                metadataUtil.generateStoredFileName(fileName);

        String storagePath =
                storageService.store(
                        pdfContent,
                        storedFileName
                );

        Document document = new Document();

        document.setOriginalFileName(fileName);
        document.setStoredFileName(storedFileName);
        document.setStoragePath(storagePath);
        document.setContentType("application/pdf");
        document.setFileSize((long) pdfContent.length);

        document.setReferenceType(
                ReferenceType.POLICY
        );

        document.setReferenceId(
                policyDTO.getPolicyId()
        );

        document.setDeleted(false);

        document = documentRepository.save(document);

        return documentMapper.toDTO(document);
    }

    @Override
    public DocumentDTO generateClaimDocument(ClaimDTO claimDTO)
            throws IOException {

        byte[] pdfContent =
                claimPdfGenerator.generate(claimDTO);

        String fileName =
                "CLAIM_" +
                        claimDTO.getClaimId() +
                        ".pdf";

        String storedFileName =
                metadataUtil.generateStoredFileName(fileName);

        String storagePath =
                storageService.store(
                        pdfContent,
                        storedFileName
                );

        Document document = new Document();

        document.setOriginalFileName(fileName);
        document.setStoredFileName(storedFileName);
        document.setStoragePath(storagePath);
        document.setContentType("application/pdf");
        document.setFileSize((long) pdfContent.length);

        document.setReferenceType(
                ReferenceType.CLAIM
        );

        document.setReferenceId(
                claimDTO.getClaimId()
        );

        document.setDeleted(false);

        document = documentRepository.save(document);

        return documentMapper.toDTO(document);
    }

    @Override
    public DocumentDTO generatePaymentReceipt(PaymentDTO paymentDTO)
            throws IOException {

        byte[] pdfContent =
                paymentPdfGenerator.generate(paymentDTO);

        String fileName =
                "PAYMENT_" +
                        paymentDTO.getPaymentId() +
                        ".pdf";

        String storedFileName =
                metadataUtil.generateStoredFileName(fileName);

        String storagePath =
                storageService.store(
                        pdfContent,
                        storedFileName
                );

        Document document = new Document();

        document.setOriginalFileName(fileName);
        document.setStoredFileName(storedFileName);
        document.setStoragePath(storagePath);
        document.setContentType("application/pdf");
        document.setFileSize((long) pdfContent.length);

        document.setReferenceType(
                ReferenceType.PAYMENT
        );

        document.setReferenceId(
                paymentDTO.getPaymentId()
        );

        document.setDeleted(false);

        document = documentRepository.save(document);

        return documentMapper.toDTO(document);
    }
}