package com.example.document_service.entity;

public enum ReferenceType {

    POLICY,

    PAYMENT,

    CLAIM,

    CUSTOMER

}