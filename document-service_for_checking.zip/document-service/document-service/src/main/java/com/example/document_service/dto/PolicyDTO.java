package com.example.document_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PolicyDTO {

    private Long policyId;

    private Long customerId;

    private String policyNumber;

    private String policyType;

    private String policyStatus;

}