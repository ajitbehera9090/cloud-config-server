package com.example.document_service.service;

import com.example.document_service.dto.*;
import com.example.document_service.entity.ReferenceType;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface DocumentService {

    DocumentDTO uploadDocument(
            DocumentUploadRequest request,
            MultipartFile file
    ) throws IOException;

    DocumentDTO generatePolicyDocument(
            PolicyDTO policyDTO
    ) throws IOException;

    DocumentDTO generateClaimDocument(
            ClaimDTO claimDTO
    ) throws IOException;

    DocumentDTO generatePaymentReceipt(
            PaymentDTO paymentDTO
    ) throws IOException;

    Resource downloadDocument(Long documentId);

    DocumentDTO getDocumentById(Long documentId);

    List<DocumentDTO> getDocumentsByReference(
            ReferenceType referenceType,
            Long referenceId
    );

    List<DocumentDTO> getDocumentsByCustomer(Long customerId);

    List<DocumentDTO> getDocumentsByPolicy(Long policyId);

    List<DocumentDTO> getDocumentsByClaim(Long claimId);

    List<DocumentDTO> getAllDocuments();

    void deleteDocument(Long documentId) throws IOException;

}