package com.example.document_service.generator;

import com.example.document_service.dto.PolicyDTO;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;

@Component
public class PolicyPdfGenerator implements PdfGenerator<PolicyDTO> {

    @Override
    public byte[] generate(PolicyDTO policy) {

        try {

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            Document document = new Document(PageSize.A4);

            PdfWriter.getInstance(document, outputStream);

            document.open();

            Font titleFont = new Font(Font.HELVETICA, 18, Font.BOLD);

            Paragraph title = new Paragraph(
                    "POLICY CERTIFICATE",
                    titleFont
            );

            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20);

            document.add(title);

            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);

            addRow(table, "Policy ID", String.valueOf(policy.getPolicyId()));
            addRow(table, "Customer ID", String.valueOf(policy.getCustomerId()));
            addRow(table, "Policy Number", policy.getPolicyNumber());
            addRow(table, "Policy Type", policy.getPolicyType());
            addRow(table, "Policy Status", policy.getPolicyStatus());

            document.add(table);

            document.add(new Paragraph(" "));

            Paragraph footer = new Paragraph(
                    "This is a computer generated policy certificate.",
                    new Font(Font.HELVETICA, 10)
            );

            footer.setAlignment(Element.ALIGN_CENTER);

            document.add(footer);

            document.close();

            return outputStream.toByteArray();

        } catch (Exception ex) {

            throw new RuntimeException("Unable to generate Policy PDF", ex);

        }

    }

    private void addRow(PdfPTable table,
                        String key,
                        String value) {

        PdfPCell keyCell = new PdfPCell(new Phrase(key));
        PdfPCell valueCell = new PdfPCell(new Phrase(value));

        table.addCell(keyCell);
        table.addCell(valueCell);

    }

}