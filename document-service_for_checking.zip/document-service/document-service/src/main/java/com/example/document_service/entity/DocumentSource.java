package com.example.document_service.entity;

public enum DocumentSource {

    USER,

    POLICY_SERVICE,

    PAYMENT_SERVICE,

    CLAIM_SERVICE,

    NOTIFICATION_SERVICE,

    ADMIN,

    SYSTEM
}