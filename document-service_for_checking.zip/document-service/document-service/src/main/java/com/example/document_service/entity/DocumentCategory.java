package com.example.document_service.entity;

public enum DocumentCategory {

    IDENTITY,

    MEDICAL,

    POLICY,

    CLAIM,

    PAYMENT,

    CUSTOMER,

    OTHER
}