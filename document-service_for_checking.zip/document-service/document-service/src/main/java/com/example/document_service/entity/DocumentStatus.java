package com.example.document_service.entity;

public enum DocumentStatus {

    ACTIVE,

    ARCHIVED,

    DELETED

}