package com.example.document_service.util;

import com.example.document_service.entity.DocumentCategory;
import com.example.document_service.entity.DocumentType;

public final class DocumentCategoryResolver {

    private DocumentCategoryResolver() {
    }

    public static DocumentCategory resolve(DocumentType documentType) {

        if (documentType == null) {
            return DocumentCategory.OTHER;
        }

        switch (documentType) {

            case POLICY_CERTIFICATE:
            case RENEWAL_CERTIFICATE:
            case WELCOME_LETTER:
                return DocumentCategory.POLICY;

            case CLAIM_ACKNOWLEDGEMENT:
            case CLAIM_APPROVAL:
            case CLAIM_REJECTION:
                return DocumentCategory.CLAIM;

            case PAYMENT_RECEIPT:
                return DocumentCategory.PAYMENT;

            default:
                return DocumentCategory.OTHER;
        }
    }
}