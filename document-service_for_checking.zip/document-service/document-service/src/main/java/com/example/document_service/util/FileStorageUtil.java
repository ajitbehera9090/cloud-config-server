package com.example.document_service.util;


import com.example.document_service.exception.DocumentStorageException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.UUID;

@Component
@Slf4j
public class FileStorageUtil {

    @Value("${file.upload-dir}")
    private String uploadDirectory;

    private Path storagePath;

    /**
     * Creates the upload directory when the application starts.
     */
    @PostConstruct
    public void initializeStorage() {

        try {

            storagePath = Paths.get(uploadDirectory)
                    .toAbsolutePath()
                    .normalize();

            Files.createDirectories(storagePath);

            log.info("Document storage initialized at : {}",
                    storagePath);

        } catch (IOException ex) {

            throw new DocumentStorageException(
                    "Could not initialize storage directory.");

        }

    }

    /**
     * Save uploaded file.
     */
    public String saveFile(MultipartFile file) throws IOException {

        if (file == null || file.isEmpty()) {

            throw new DocumentStorageException(
                    "Cannot store empty file.");

        }

        String originalName = file.getOriginalFilename();

        String extension = "";

        if (originalName != null && originalName.contains(".")) {

            extension = originalName.substring(
                    originalName.lastIndexOf("."));

        }

        String storedFileName =
                UUID.randomUUID() + extension;

        Path targetLocation =
                storagePath.resolve(storedFileName);

        Files.copy(
                file.getInputStream(),
                targetLocation,
                StandardCopyOption.REPLACE_EXISTING);

        log.info("File stored successfully : {}",
                storedFileName);

        return storedFileName;

    }

    /**
     * Returns the full file path.
     */
    public Path getFilePath(String storedFileName) {

        return storagePath.resolve(storedFileName);

    }

    /**
     * Load file as Spring Resource.
     */
    public Resource loadFile(String storedFileName) {

        try {

            Path filePath =
                    getFilePath(storedFileName);

            Resource resource =
                    new UrlResource(filePath.toUri());

            if (resource.exists()) {

                return resource;

            }

            throw new DocumentStorageException(
                    "File not found.");

        } catch (MalformedURLException ex) {

            throw new DocumentStorageException(
                    "Unable to load file.");

        }

    }

    /**
     * Delete physical file.
     */
    public void deleteFile(String storedFileName)
            throws IOException {

        Path filePath =
                getFilePath(storedFileName);

        Files.deleteIfExists(filePath);

        log.info("File deleted : {}", storedFileName);

    }

}