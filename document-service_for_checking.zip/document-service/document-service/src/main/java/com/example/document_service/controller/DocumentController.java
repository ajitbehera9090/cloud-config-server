package com.example.document_service.controller;


import com.example.document_service.dto.DocumentDTO;
import com.example.document_service.dto.DocumentUploadRequest;
import com.example.document_service.service.DocumentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/documents")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;

    /**
     * Upload a document.
     */
    @PostMapping(
            value = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<DocumentDTO> uploadDocument(

            @Valid
            @ModelAttribute DocumentUploadRequest request,

            @RequestPart("file") MultipartFile file)

            throws IOException {

        return ResponseEntity.ok(
                documentService.uploadDocument(request, file));

    }

    /**
     * Get document by id.
     */
    @GetMapping("/{documentId}")
    public ResponseEntity<DocumentDTO> getDocumentById(
            @PathVariable Long documentId) {

        return ResponseEntity.ok(
                documentService.getDocumentById(documentId));

    }

    /**
     * Get all documents.
     */
    @GetMapping
    public ResponseEntity<List<DocumentDTO>> getAllDocuments() {

        return ResponseEntity.ok(
                documentService.getAllDocuments());

    }

    /**
     * Get customer documents.
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<DocumentDTO>> getCustomerDocuments(
            @PathVariable Long customerId) {

        return ResponseEntity.ok(
                documentService.getDocumentsByCustomer(customerId));

    }

    /**
     * Get policy documents.
     */
    @GetMapping("/policy/{policyId}")
    public ResponseEntity<List<DocumentDTO>> getPolicyDocuments(
            @PathVariable Long policyId) {

        return ResponseEntity.ok(
                documentService.getDocumentsByPolicy(policyId));

    }

    /**
     * Get claim documents.
     */
    @GetMapping("/claim/{claimId}")
    public ResponseEntity<List<DocumentDTO>> getClaimDocuments(
            @PathVariable Long claimId) {

        return ResponseEntity.ok(
                documentService.getDocumentsByClaim(claimId));

    }

    /**
     * Delete document.
     */
    @DeleteMapping("/{documentId}")
    public ResponseEntity<String> deleteDocument(
            @PathVariable Long documentId)
            throws IOException {

        documentService.deleteDocument(documentId);

        return ResponseEntity.ok(
                "Document deleted successfully.");

    }

    @GetMapping("/download/{documentId}")
    public ResponseEntity<Resource> downloadDocument(
            @PathVariable Long documentId) {

        Resource resource =
                documentService.downloadDocument(documentId);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        ContentDisposition.attachment()
                                .filename(resource.getFilename())
                                .build()
                                .toString())
                .body(resource);

    }

}