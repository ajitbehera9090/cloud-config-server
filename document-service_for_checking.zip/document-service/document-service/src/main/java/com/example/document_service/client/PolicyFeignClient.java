package com.example.document_service.client;


import com.example.document_service.dto.PolicyDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "POLICY-SERVICE")
public interface PolicyFeignClient {

    @GetMapping("/policies/{policyId}")
    PolicyDTO getPolicyById(
            @PathVariable Long policyId);

}