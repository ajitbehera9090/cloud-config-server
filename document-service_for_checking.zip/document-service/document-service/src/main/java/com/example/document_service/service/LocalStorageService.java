package com.example.document_service.service;

import com.example.document_service.exception.DocumentStorageException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;

@Service
public class LocalStorageService implements StorageService {

    @Value("${document.storage.root-folder}")
    private String rootFolder;

    private Path storageLocation;

    @PostConstruct
    public void init() {

        try {

            storageLocation = Paths.get(rootFolder)
                    .toAbsolutePath()
                    .normalize();

            Files.createDirectories(storageLocation);

        } catch (IOException ex) {

            throw new DocumentStorageException(
                    "Unable to initialize document storage.",
                    ex
            );

        }

    }

    @Override
    public String store(MultipartFile file,
                        String storedFileName) throws IOException {

        Path target = storageLocation.resolve(storedFileName);

        Files.copy(
                file.getInputStream(),
                target,
                StandardCopyOption.REPLACE_EXISTING
        );

        return target.toString();

    }

    @Override
    public String store(byte[] pdfBytes,
                        String storedFileName) throws IOException {

        Path target = storageLocation.resolve(storedFileName);

        Files.write(target, pdfBytes);

        return target.toString();

    }

    @Override
    public Resource load(String storedFileName) {

        try {

            Path path = storageLocation.resolve(storedFileName)
                    .normalize();

            Resource resource = new UrlResource(path.toUri());

            if (resource.exists()) {

                return resource;

            }

            throw new DocumentStorageException(
                    "Document not found."
            );

        } catch (MalformedURLException ex) {

            throw new DocumentStorageException(
                    "Unable to load document.",
                    ex
            );

        }

    }

    @Override
    public void delete(String storedFileName)
            throws IOException {

        Path path = storageLocation.resolve(storedFileName);

        Files.deleteIfExists(path);

    }

    @Override
    public boolean exists(String storedFileName) {

        Path path = storageLocation.resolve(storedFileName);

        return Files.exists(path);

    }

}