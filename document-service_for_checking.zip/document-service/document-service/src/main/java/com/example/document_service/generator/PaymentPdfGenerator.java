package com.example.document_service.generator;


import com.example.document_service.dto.PaymentDTO;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;

@Component
public class PaymentPdfGenerator implements PdfGenerator<PaymentDTO> {

    @Override
    public byte[] generate(PaymentDTO payment) {

        try {

            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            Document document = new Document(PageSize.A4);

            PdfWriter.getInstance(document, outputStream);

            document.open();

            document.add(new Paragraph(
                    "PAYMENT RECEIPT",
                    new Font(Font.HELVETICA, 18, Font.BOLD)
            ));

            document.add(new Paragraph(" "));

            document.add(new Paragraph("Transaction ID : " + payment.getTransactionId()));
            document.add(new Paragraph("Customer Name : " + payment.getCustomerName()));
            document.add(new Paragraph("Amount : " + payment.getAmount()));
            document.add(new Paragraph("Payment Method : " + payment.getPaymentMethod()));
            document.add(new Paragraph("Payment Date : " + payment.getPaymentDate()));

            document.close();

            return outputStream.toByteArray();

        } catch (Exception ex) {

            throw new RuntimeException(
                    "Unable to generate payment PDF.",
                    ex
            );

        }

    }

}