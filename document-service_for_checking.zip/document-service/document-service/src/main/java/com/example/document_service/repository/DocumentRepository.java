package com.example.document_service.repository;

import com.example.document_service.entity.Document;
import com.example.document_service.entity.DocumentStatus;
import com.example.document_service.entity.DocumentType;
import com.example.document_service.entity.ReferenceType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DocumentRepository extends JpaRepository<Document, Long> {

    Optional<Document> findByDocumentIdAndDeletedFalse(Long documentId);

    List<Document> findByReferenceTypeAndReferenceIdAndDeletedFalse(
            ReferenceType referenceType,
            Long referenceId
    );

    List<Document> findByDocumentTypeAndDeletedFalse(
            DocumentType documentType
    );

    List<Document> findByStatusAndDeletedFalse(
            DocumentStatus status
    );

    List<Document> findByDeletedFalse();

    boolean existsByReferenceTypeAndReferenceIdAndDocumentTypeAndDeletedFalse(
            ReferenceType referenceType,
            Long referenceId,
            DocumentType documentType
    );

}