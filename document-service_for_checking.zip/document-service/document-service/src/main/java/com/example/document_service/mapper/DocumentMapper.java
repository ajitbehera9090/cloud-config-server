package com.example.document_service.mapper;

import com.example.document_service.dto.DocumentDTO;
import com.example.document_service.entity.Document;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface DocumentMapper {

    DocumentDTO toDTO(Document entity);

    Document toEntity(DocumentDTO dto);

}