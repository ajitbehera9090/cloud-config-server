//package com.example.document_service.util;
//
//import com.example.document_service.dto.*;
//import com.example.document_service.entity.*;
//import org.springframework.stereotype.Component;
//
//import java.io.IOException;
//import java.util.UUID;
//
//@Component
//public class DocumentMetadataUtil {
//
//    /**
//     * Generates UUID based stored filename.
//     */
//    public String generateStoredFileName(String originalFileName) {
//
//        String extension = "";
//
//        int index = originalFileName.lastIndexOf(".");
//
//        if (index != -1) {
//            extension = originalFileName.substring(index);
//        }
//
//        return UUID.randomUUID() + extension;
//    }
//
//    /**
//     * Creates Document entity for uploaded documents.
//     */
//    public Document buildDocument(DocumentUploadRequest request,
//                                  String storedFileName,
//                                  String storagePath,
//                                  String contentType,
//                                  Long fileSize) {
//
//        return Document.builder()
//                .referenceType(request.getReferenceType())
//                .referenceId(request.getReferenceId())
//                .documentType(request.getDocumentType())
//                .originalFileName(request.getOriginalFileName())
//                .storedFileName(storedFileName)
//                .storagePath(storagePath)
//                .contentType(contentType)
//                .fileSize(fileSize)
//                .checksum(null)
//                .version(1)
//                .generatedBy(GeneratedBy.USER)
//                .status(DocumentStatus.ACTIVE)
//                .deleted(false)
//                .build();
//    }
//
//    @Override
//    public DocumentDTO generatePolicyDocument(PolicyDTO policyDTO)
//            throws IOException {
//
//        byte[] pdf = policyPdfGenerator.generate(policyDTO);
//
//        String fileName = policyDTO.getPolicyNumber() + ".pdf";
//
//        String storedFileName =
//                metadataUtil.generateStoredFileName(fileName);
//
//        String storagePath =
//                storageService.store(pdf, storedFileName);
//
//        Document document = Document.builder()
//                .referenceType(ReferenceType.POLICY)
//                .referenceId(policyDTO.getPolicyId())
//                .documentType(DocumentType.POLICY_CERTIFICATE)
//                .originalFileName(fileName)
//                .storedFileName(storedFileName)
//                .storagePath(storagePath)
//                .contentType("application/pdf")
//                .fileSize((long) pdf.length)
//                .checksum(null)
//                .version(1)
//                .generatedBy(GeneratedBy.SYSTEM)
//                .status(DocumentStatus.ACTIVE)
//                .deleted(false)
//                .build();
//
//        document = documentRepository.save(document);
//
//        return documentMapper.toDTO(document);
//    }
//
//    @Override
//    public DocumentDTO generateClaimDocument(ClaimDTO claimDTO)
//            throws IOException {
//
//        byte[] pdf = claimPdfGenerator.generate(claimDTO);
//
//        String fileName = claimDTO.getClaimNumber() + ".pdf";
//
//        String storedFileName =
//                metadataUtil.generateStoredFileName(fileName);
//
//        String storagePath =
//                storageService.store(pdf, storedFileName);
//
//        Document document = Document.builder()
//                .referenceType(ReferenceType.CLAIM)
//                .referenceId(claimDTO.getClaimId())
//                .documentType(DocumentType.CLAIM_ACKNOWLEDGEMENT)
//                .originalFileName(fileName)
//                .storedFileName(storedFileName)
//                .storagePath(storagePath)
//                .contentType("application/pdf")
//                .fileSize((long) pdf.length)
//                .checksum(null)
//                .version(1)
//                .generatedBy(GeneratedBy.SYSTEM)
//                .status(DocumentStatus.ACTIVE)
//                .deleted(false)
//                .build();
//
//        document = documentRepository.save(document);
//
//        return documentMapper.toDTO(document);
//    }
//
//    @Override
//    public DocumentDTO generatePaymentReceipt(PaymentDTO paymentDTO)
//            throws IOException {
//
//        byte[] pdf = paymentPdfGenerator.generate(paymentDTO);
//
//        String fileName =
//                paymentDTO.getTransactionId() + ".pdf";
//
//        String storedFileName =
//                metadataUtil.generateStoredFileName(fileName);
//
//        String storagePath =
//                storageService.store(pdf, storedFileName);
//
//        Document document = Document.builder()
//                .referenceType(ReferenceType.PAYMENT)
//                .referenceId(paymentDTO.getPaymentId())
//                .documentType(DocumentType.PAYMENT_RECEIPT)
//                .originalFileName(fileName)
//                .storedFileName(storedFileName)
//                .storagePath(storagePath)
//                .contentType("application/pdf")
//                .fileSize((long) pdf.length)
//                .checksum(null)
//                .version(1)
//                .generatedBy(GeneratedBy.SYSTEM)
//                .status(DocumentStatus.ACTIVE)
//                .deleted(false)
//                .build();
//
//        document = documentRepository.save(document);
//
//        return documentMapper.toDTO(document);
//    }
//
//    @Override
//    public DocumentDTO generatePaymentReceipt(PaymentDTO paymentDTO)
//            throws IOException {
//
//        byte[] pdf = paymentPdfGenerator.generate(paymentDTO);
//
//        String fileName =
//                paymentDTO.getTransactionId() + ".pdf";
//
//        String storedFileName =
//                metadataUtil.generateStoredFileName(fileName);
//
//        String storagePath =
//                storageService.store(pdf, storedFileName);
//
//        Document document = Document.builder()
//                .referenceType(ReferenceType.PAYMENT)
//                .referenceId(paymentDTO.getPaymentId())
//                .documentType(DocumentType.PAYMENT_RECEIPT)
//                .originalFileName(fileName)
//                .storedFileName(storedFileName)
//                .storagePath(storagePath)
//                .contentType("application/pdf")
//                .fileSize((long) pdf.length)
//                .checksum(null)
//                .version(1)
//                .generatedBy(GeneratedBy.SYSTEM)
//                .status(DocumentStatus.ACTIVE)
//                .deleted(false)
//                .build();
//
//        document = documentRepository.save(document);
//
//        return documentMapper.toDTO(document);
//    }
//
//}


package com.example.document_service.util;

import com.example.document_service.dto.DocumentUploadRequest;
import com.example.document_service.entity.Document;
import com.example.document_service.entity.DocumentStatus;
import com.example.document_service.entity.GeneratedBy;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class DocumentMetadataUtil {

    /**
     * Generates UUID-based stored filename.
     */
    public String generateStoredFileName(String originalFileName) {

        String extension = "";

        int index = originalFileName.lastIndexOf(".");

        if (index != -1) {
            extension = originalFileName.substring(index);
        }

        return UUID.randomUUID() + extension;
    }

    /**
     * Creates Document entity for uploaded documents.
     */
    public Document buildDocument(
            DocumentUploadRequest request,
            String storedFileName,
            String storagePath,
            String contentType,
            Long fileSize) {

        return Document.builder()
                .referenceType(request.getReferenceType())
                .referenceId(request.getReferenceId())
                .documentType(request.getDocumentType())
                .originalFileName(request.getOriginalFileName())
                .storedFileName(storedFileName)
                .storagePath(storagePath)
                .contentType(contentType)
                .fileSize(fileSize)
                .checksum(null)
                .version(1)
                .generatedBy(GeneratedBy.USER)
                .status(DocumentStatus.ACTIVE)
                .deleted(false)
                .build();
    }
}