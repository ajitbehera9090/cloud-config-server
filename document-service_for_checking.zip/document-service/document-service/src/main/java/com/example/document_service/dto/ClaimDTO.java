package com.example.document_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ClaimDTO {

    private Long claimId;

    private Long customerId;

    private Long policyId;

    private String claimNumber;

    private String claimStatus;

}