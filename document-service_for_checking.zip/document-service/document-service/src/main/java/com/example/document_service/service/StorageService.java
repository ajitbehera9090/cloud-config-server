package com.example.document_service.service;

import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface StorageService {

    /**
     * Store uploaded file.
     *
     * @param file uploaded file
     * @param storedFileName UUID based filename
     * @return absolute storage path
     */
    String store(MultipartFile file, String storedFileName) throws IOException;

    /**
     * Store generated PDF.
     *
     * @param pdfBytes PDF bytes
     * @param storedFileName UUID filename
     * @return absolute storage path
     */
    String store(byte[] pdfBytes, String storedFileName) throws IOException;

    /**
     * Load document.
     */
    Resource load(String storedFileName);

    /**
     * Delete document.
     */
    void delete(String storedFileName) throws IOException;

    /**
     * Check existence.
     */
    boolean exists(String storedFileName);

}