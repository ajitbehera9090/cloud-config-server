package com.example.document_service.client;


import com.example.document_service.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "CUSTOMER-SERVICE")
public interface CustomerFeignClient {

    @GetMapping("/customers/{customerId}")
    CustomerDTO getCustomerById(
            @PathVariable Long customerId);

}