package com.example.document_service.generator;

public interface PdfGenerator<T> {

    byte[] generate(T data);

}