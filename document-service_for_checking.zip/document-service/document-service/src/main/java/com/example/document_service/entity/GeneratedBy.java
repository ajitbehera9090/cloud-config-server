package com.example.document_service.entity;

public enum GeneratedBy {

    SYSTEM,

    USER

}