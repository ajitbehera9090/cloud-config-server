package com.insurance.claims_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
