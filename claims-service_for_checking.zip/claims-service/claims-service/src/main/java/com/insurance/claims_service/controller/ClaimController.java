package com.insurance.claims_service.controller;


import com.insurance.claims_service.dto.ClaimDTO;
import com.insurance.claims_service.service.ClaimService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/claims")
@RequiredArgsConstructor
public class ClaimController {

    private final ClaimService claimService;

    @PostMapping
    public ClaimDTO createClaim(
            @Valid @RequestBody ClaimDTO claimDTO) {

        return claimService.createClaim(claimDTO);
    }

    @GetMapping("/{id}")
    public ClaimDTO getClaimById(
            @PathVariable Long id) {

        return claimService.getClaimById(id);
    }

    @GetMapping
    public List<ClaimDTO> getAllClaims() {

        return claimService.getAllClaims();
    }

    @PutMapping("/{id}")
    public ClaimDTO updateClaim(
            @PathVariable Long id,
            @Valid @RequestBody ClaimDTO claimDTO) {

        return claimService.updateClaim(id, claimDTO);
    }

    @DeleteMapping("/{id}")
    public void deleteClaim(
            @PathVariable Long id) {

        claimService.deleteClaim(id);
    }
}