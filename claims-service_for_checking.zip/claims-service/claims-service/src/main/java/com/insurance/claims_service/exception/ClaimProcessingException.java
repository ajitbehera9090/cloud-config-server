package com.insurance.claims_service.exception;

public class ClaimProcessingException extends RuntimeException {


    public ClaimProcessingException(String message) {
        super(message);
    }


}
