package com.insurance.claims_service.exception;

public class ClaimNotFoundException extends RuntimeException {


    public ClaimNotFoundException(String message) {
        super(message);
    }


}
