package com.insurance.claims_service.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class ClaimDTO {

    private Long claimId;

    @NotNull
    private Long customerId;

    @NotNull
    private Long policyId;

    @NotBlank
    private String claimNumber;

    @NotNull
    private BigDecimal claimAmount;

    @NotBlank
    private String claimReason;

    @NotBlank
    private String claimStatus;

    @Valid
    private List<ClaimDocumentDTO> documents;
}