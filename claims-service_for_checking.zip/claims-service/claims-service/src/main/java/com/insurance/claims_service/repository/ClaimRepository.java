package com.insurance.claims_service.repository;


import com.insurance.claims_service.entity.Claim;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.util.List;

public interface ClaimRepository
        extends JpaRepository<Claim, Long> {

    /*
     * Duplicate Validation
     */
    boolean existsByClaimNumber(String claimNumber);

    /*
     * Search by Claim Number
     */
    Claim findByClaimNumber(String claimNumber);

    /*
     * Search by Customer
     */
    List<Claim> findByCustomerId(Long customerId);

    /*
     * Search by Policy
     */
    List<Claim> findByPolicyId(Long policyId);

    /*
     * Search by Status
     */
    List<Claim> findByClaimStatus(String claimStatus);

    /*
     * Search by Reason
     */
    List<Claim> findByClaimReason(String claimReason);

    /*
     * Search by Amount
     */
    List<Claim> findByClaimAmountGreaterThan(
            BigDecimal amount);

    List<Claim> findByClaimAmountLessThan(
            BigDecimal amount);

    /*
     * Combined Searches
     */
    List<Claim> findByCustomerIdAndClaimStatus(
            Long customerId,
            String claimStatus);

    List<Claim> findByPolicyIdAndClaimStatus(
            Long policyId,
            String claimStatus);

    /*
     * Pagination
     */
    Page<Claim> findByClaimStatus(
            String claimStatus,
            Pageable pageable);

    Page<Claim> findAll(Pageable pageable);
}