package com.insurance.claims_service.exception;

public class CustomerValidationException extends RuntimeException {


    public CustomerValidationException(String message) {
        super(message);
    }


}
