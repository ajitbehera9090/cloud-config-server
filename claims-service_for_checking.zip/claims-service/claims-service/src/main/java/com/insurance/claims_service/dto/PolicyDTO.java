package com.insurance.claims_service.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class PolicyDTO {

    private Long policyId;

    private Long customerId;

    private String policyNumber;

    private String policyType;

    private BigDecimal premiumAmount;

    private BigDecimal sumAssured;
}