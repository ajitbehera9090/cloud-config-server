package com.insurance.claims_service.repository;


import com.insurance.claims_service.entity.ClaimDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClaimDocumentRepository
        extends JpaRepository<ClaimDocument, Long> {
}