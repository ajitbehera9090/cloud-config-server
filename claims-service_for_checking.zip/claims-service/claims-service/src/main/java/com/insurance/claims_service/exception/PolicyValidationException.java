package com.insurance.claims_service.exception;

public class PolicyValidationException extends RuntimeException {


    public PolicyValidationException(String message) {
        super(message);
    }


}
