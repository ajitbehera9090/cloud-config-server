package com.insurance.claims_service.service;


import com.insurance.claims_service.dto.ClaimDTO;
import org.springframework.data.domain.Page;

import java.math.BigDecimal;
import java.util.List;

public interface ClaimService {

    /*
     * CRUD Operations
     */
    ClaimDTO createClaim(ClaimDTO claimDTO);

    ClaimDTO getClaimById(Long claimId);

    List<ClaimDTO> getAllClaims();

    ClaimDTO updateClaim(
            Long claimId,
            ClaimDTO claimDTO);

    void deleteClaim(Long claimId);

    /*
     * Search Operations
     */
    ClaimDTO getClaimByClaimNumber(
            String claimNumber);

    List<ClaimDTO> getClaimsByCustomerId(
            Long customerId);

    List<ClaimDTO> getClaimsByPolicyId(
            Long policyId);

    List<ClaimDTO> getClaimsByStatus(
            String claimStatus);

    List<ClaimDTO> getClaimsByReason(
            String claimReason);

    List<ClaimDTO> getClaimsByAmountGreaterThan(
            BigDecimal amount);

    List<ClaimDTO> getClaimsByAmountLessThan(
            BigDecimal amount);

    List<ClaimDTO> getClaimsByCustomerIdAndStatus(
            Long customerId,
            String claimStatus);

    List<ClaimDTO> getClaimsByPolicyIdAndStatus(
            Long policyId,
            String claimStatus);

    /*
     * Pagination
     */
    Page<ClaimDTO> getClaimsByStatusWithPagination(
            String claimStatus,
            int page,
            int size,
            String sortBy);

    Page<ClaimDTO> getAllClaimsWithPagination(
            int page,
            int size,
            String sortBy);
}