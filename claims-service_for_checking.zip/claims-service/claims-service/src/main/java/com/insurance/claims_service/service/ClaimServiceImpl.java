package com.insurance.claims_service.service;


import com.insurance.claims_service.client.CustomerFeignClient;
import com.insurance.claims_service.client.PolicyFeignClient;
import com.insurance.claims_service.dto.ClaimDTO;
import com.insurance.claims_service.dto.ClaimDocumentDTO;
import com.insurance.claims_service.dto.CustomerDTO;
import com.insurance.claims_service.dto.PolicyDTO;
import com.insurance.claims_service.entity.Claim;
import com.insurance.claims_service.entity.ClaimDocument;
import com.insurance.claims_service.exception.ClaimAlreadyExistsException;
import com.insurance.claims_service.exception.ClaimNotFoundException;
import com.insurance.claims_service.exception.CustomerValidationException;
import com.insurance.claims_service.exception.PolicyValidationException;
import com.insurance.claims_service.repository.ClaimRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ClaimServiceImpl implements ClaimService {

    private final ClaimRepository claimRepository;

    private final CustomerFeignClient customerFeignClient;

    private final PolicyFeignClient policyFeignClient;

    /*
     * Create Claim
     */
    @Override
    public ClaimDTO createClaim(
            ClaimDTO claimDTO) {

        if (claimRepository.existsByClaimNumber(
                claimDTO.getClaimNumber())) {

            throw new ClaimAlreadyExistsException(
                    "Claim already exists with claim number : "
                            + claimDTO.getClaimNumber());
        }

        CustomerDTO customer =
                customerFeignClient.getCustomerById(
                        claimDTO.getCustomerId());

        if (customer == null) {

            throw new CustomerValidationException(
                    "Claim cannot be registered because customer is invalid");
        }

        PolicyDTO policy =
                policyFeignClient.getPolicyById(
                        claimDTO.getPolicyId());

        if (policy == null) {

            throw new PolicyValidationException(
                    "Claim cannot be registered because policy is invalid");
        }

        Claim claim = dtoToEntity(claimDTO);

        Claim savedClaim =
                claimRepository.save(claim);

        return entityToDto(savedClaim);
    }

    /*
     * Get Claim By Id
     */
    @Override
    public ClaimDTO getClaimById(
            Long claimId) {

        Claim claim =
                claimRepository.findById(claimId)
                        .orElseThrow(() ->
                                new ClaimNotFoundException(
                                        "Claim not found with id : "
                                                + claimId));

        return entityToDto(claim);
    }

    /*
     * Get All Claims
     */
    @Override
    public List<ClaimDTO> getAllClaims() {

        List<Claim> claims =
                claimRepository.findAll();

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(
                    entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Update Claim
     */
    @Override
    public ClaimDTO updateClaim(
            Long claimId,
            ClaimDTO claimDTO) {

        Claim existingClaim =
                claimRepository.findById(claimId)
                        .orElseThrow(() ->
                                new ClaimNotFoundException(
                                        "Claim not found with id : "
                                                + claimId));

        CustomerDTO customer =
                customerFeignClient.getCustomerById(
                        claimDTO.getCustomerId());

        if (customer == null) {

            throw new CustomerValidationException(
                    "Customer validation failed");
        }

        PolicyDTO policy =
                policyFeignClient.getPolicyById(
                        claimDTO.getPolicyId());

        if (policy == null) {

            throw new PolicyValidationException(
                    "Policy validation failed");
        }

        existingClaim.setClaimNumber(
                claimDTO.getClaimNumber());

        existingClaim.setCustomerId(
                claimDTO.getCustomerId());

        existingClaim.setPolicyId(
                claimDTO.getPolicyId());

        existingClaim.setClaimAmount(
                claimDTO.getClaimAmount());

        existingClaim.setClaimReason(
                claimDTO.getClaimReason());

        existingClaim.setClaimStatus(
                claimDTO.getClaimStatus());

        /*
         * Document Update
         */
        existingClaim.getDocuments().clear();

        if (claimDTO.getDocuments() != null) {

            for (ClaimDocumentDTO documentDTO
                    : claimDTO.getDocuments()) {

                ClaimDocument document =
                        new ClaimDocument();

                document.setDocumentName(
                        documentDTO.getDocumentName());

                document.setDocumentType(
                        documentDTO.getDocumentType());

                document.setClaim(existingClaim);

                existingClaim.getDocuments()
                        .add(document);
            }
        }

        Claim updatedClaim =
                claimRepository.save(existingClaim);

        return entityToDto(updatedClaim);
    }

    /*
     * Delete Claim
     */
    @Override
    public void deleteClaim(
            Long claimId) {

        Claim claim =
                claimRepository.findById(claimId)
                        .orElseThrow(() ->
                                new ClaimNotFoundException(
                                        "Claim not found with id : "
                                                + claimId));

        claimRepository.delete(claim);
    }

    /*
     * Search By Claim Number
     */
    @Override
    public ClaimDTO getClaimByClaimNumber(
            String claimNumber) {

        Claim claim =
                claimRepository.findByClaimNumber(
                        claimNumber);

        if (claim == null) {

            throw new ClaimNotFoundException(
                    "Claim not found with claim number : "
                            + claimNumber);
        }

        return entityToDto(claim);
    }

    /*
     * Search By Customer
     */
    @Override
    public List<ClaimDTO> getClaimsByCustomerId(
            Long customerId) {

        List<Claim> claims =
                claimRepository.findByCustomerId(
                        customerId);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Policy
     */
    @Override
    public List<ClaimDTO> getClaimsByPolicyId(
            Long policyId) {

        List<Claim> claims =
                claimRepository.findByPolicyId(
                        policyId);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Status
     */
    @Override
    public List<ClaimDTO> getClaimsByStatus(
            String claimStatus) {

        List<Claim> claims =
                claimRepository.findByClaimStatus(
                        claimStatus);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Reason
     */
    @Override
    public List<ClaimDTO> getClaimsByReason(
            String claimReason) {

        List<Claim> claims =
                claimRepository.findByClaimReason(
                        claimReason);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Amount Greater Than
     */
    @Override
    public List<ClaimDTO> getClaimsByAmountGreaterThan(
            BigDecimal amount) {

        List<Claim> claims =
                claimRepository.findByClaimAmountGreaterThan(
                        amount);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Amount Less Than
     */
    @Override
    public List<ClaimDTO> getClaimsByAmountLessThan(
            BigDecimal amount) {

        List<Claim> claims =
                claimRepository.findByClaimAmountLessThan(
                        amount);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Customer And Status
     */
    @Override
    public List<ClaimDTO> getClaimsByCustomerIdAndStatus(
            Long customerId,
            String claimStatus) {

        List<Claim> claims =
                claimRepository.findByCustomerIdAndClaimStatus(
                        customerId,
                        claimStatus);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Search By Policy And Status
     */
    @Override
    public List<ClaimDTO> getClaimsByPolicyIdAndStatus(
            Long policyId,
            String claimStatus) {

        List<Claim> claims =
                claimRepository.findByPolicyIdAndClaimStatus(
                        policyId,
                        claimStatus);

        List<ClaimDTO> dtoList =
                new ArrayList<>();

        for (Claim claim : claims) {

            dtoList.add(entityToDto(claim));
        }

        return dtoList;
    }

    /*
     * Pagination By Status
     */
    @Override
    public Page<ClaimDTO> getClaimsByStatusWithPagination(
            String claimStatus,
            int page,
            int size,
            String sortBy) {

        Pageable pageable =
                PageRequest.of(
                        page,
                        size,
                        Sort.by(sortBy));

        Page<Claim> claimPage =
                claimRepository.findByClaimStatus(
                        claimStatus,
                        pageable);

        return claimPage.map(this::entityToDto);
    }

    /*
     * Pagination For All Claims
     */
    @Override
    public Page<ClaimDTO> getAllClaimsWithPagination(
            int page,
            int size,
            String sortBy) {

        Pageable pageable =
                PageRequest.of(
                        page,
                        size,
                        Sort.by(sortBy));

        Page<Claim> claimPage =
                claimRepository.findAll(pageable);

        return claimPage.map(this::entityToDto);
    }

    /*
     * DTO -> Entity Mapping
     */
    private Claim dtoToEntity(
            ClaimDTO dto) {

        Claim claim = new Claim();

        claim.setClaimId(dto.getClaimId());

        claim.setClaimNumber(
                dto.getClaimNumber());

        claim.setCustomerId(
                dto.getCustomerId());

        claim.setPolicyId(
                dto.getPolicyId());

        claim.setClaimAmount(
                dto.getClaimAmount());

        claim.setClaimReason(
                dto.getClaimReason());

        claim.setClaimStatus(
                dto.getClaimStatus());

        if (dto.getDocuments() != null) {

            for (ClaimDocumentDTO documentDTO
                    : dto.getDocuments()) {

                ClaimDocument document =
                        new ClaimDocument();

                document.setDocumentId(
                        documentDTO.getDocumentId());

                document.setDocumentName(
                        documentDTO.getDocumentName());

                document.setDocumentType(
                        documentDTO.getDocumentType());

                document.setClaim(claim);

                claim.getDocuments()
                        .add(document);
            }
        }

        return claim;
    }

    /*
     * Entity -> DTO Mapping
     */
    private ClaimDTO entityToDto(
            Claim claim) {

        ClaimDTO dto = new ClaimDTO();

        dto.setClaimId(
                claim.getClaimId());

        dto.setClaimNumber(
                claim.getClaimNumber());

        dto.setCustomerId(
                claim.getCustomerId());

        dto.setPolicyId(
                claim.getPolicyId());

        dto.setClaimAmount(
                claim.getClaimAmount());

        dto.setClaimReason(
                claim.getClaimReason());

        dto.setClaimStatus(
                claim.getClaimStatus());

        List<ClaimDocumentDTO> documentDTOList =
                new ArrayList<>();

        if (claim.getDocuments() != null) {

            for (ClaimDocument document
                    : claim.getDocuments()) {

                ClaimDocumentDTO documentDTO =
                        new ClaimDocumentDTO();

                documentDTO.setDocumentId(
                        document.getDocumentId());

                documentDTO.setDocumentName(
                        document.getDocumentName());

                documentDTO.setDocumentType(
                        document.getDocumentType());

                documentDTOList.add(documentDTO);
            }
        }

        dto.setDocuments(documentDTOList);

        return dto;
    }
}