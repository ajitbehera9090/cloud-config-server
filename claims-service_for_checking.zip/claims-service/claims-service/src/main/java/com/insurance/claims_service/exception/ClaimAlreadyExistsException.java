package com.insurance.claims_service.exception;

public class ClaimAlreadyExistsException extends RuntimeException {


    public ClaimAlreadyExistsException(String message) {
        super(message);
    }


}
