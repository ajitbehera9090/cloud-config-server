package com.insurance.claims_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ClaimDocumentDTO {

    private Long documentId;

    @NotBlank
    private String documentName;

    @NotBlank
    private String documentType;
}