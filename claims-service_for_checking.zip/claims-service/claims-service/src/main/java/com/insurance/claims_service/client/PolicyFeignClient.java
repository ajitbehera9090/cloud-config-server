package com.insurance.claims_service.client;

import com.insurance.claims_service.dto.PolicyDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "POLICY-SERVICE")
public interface PolicyFeignClient {

    @GetMapping("/policies/{id}")
    PolicyDTO getPolicyById(
            @PathVariable("id") Long id);

}