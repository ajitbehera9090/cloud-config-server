package com.insurance.customer_service.service;


import com.insurance.customer_service.dto.CustomerDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface CustomerService {

    CustomerDTO createCustomer(CustomerDTO customerDTO);

    CustomerDTO getCustomerById(Long customerId);

    List<CustomerDTO> getAllCustomers();

    CustomerDTO updateCustomer(
            Long customerId,
            CustomerDTO customerDTO);

    void deleteCustomer(Long customerId);

    CustomerDTO getCustomerByEmail(String email);

    CustomerDTO getCustomerByMobileNumber(
            String mobileNumber);

    List<CustomerDTO> getCustomersByGender(
            String gender);

    Page<CustomerDTO> getCustomersWithPagination(
            int page,
            int size,
            String sortBy);
}