package com.insurance.customer_service.repository;


import com.insurance.customer_service.entity.Customer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerRepository
        extends JpaRepository<Customer, Long> {

    boolean existsByEmail(String email);

    boolean existsByMobileNumber(String mobileNumber);

    Customer findByEmail(String email);

    Customer findByMobileNumber(String mobileNumber);

    List<Customer> findByGender(String gender);

    Page<Customer> findAll(Pageable pageable);
}