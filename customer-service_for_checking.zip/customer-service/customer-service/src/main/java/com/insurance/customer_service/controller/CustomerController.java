package com.insurance.customer_service.controller;


import com.insurance.customer_service.dto.CustomerDTO;
import com.insurance.customer_service.service.CustomerService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customers")
@RequiredArgsConstructor
public class CustomerController {

    private final CustomerService customerService;

    @PostMapping
    public CustomerDTO createCustomer(
            @Valid @RequestBody CustomerDTO customerDTO) {

        return customerService.createCustomer(customerDTO);
    }

    @GetMapping("/{customerId}")
    public CustomerDTO getCustomerById(
            @PathVariable Long customerId) {

        return customerService.getCustomerById(customerId);
    }

    @GetMapping
    public List<CustomerDTO> getAllCustomers() {

        return customerService.getAllCustomers();
    }

    @PutMapping("/{customerId}")
    public CustomerDTO updateCustomer(
            @PathVariable Long customerId,
            @Valid @RequestBody CustomerDTO customerDTO) {

        return customerService.updateCustomer(
                customerId,
                customerDTO);
    }

    @DeleteMapping("/{customerId}")
    public void deleteCustomer(
            @PathVariable Long customerId) {

        customerService.deleteCustomer(customerId);
    }

    @GetMapping("/email/{email}")
    public CustomerDTO getCustomerByEmail(
            @PathVariable String email) {

        return customerService.getCustomerByEmail(email);
    }

    @GetMapping("/mobile/{mobileNumber}")
    public CustomerDTO getCustomerByMobileNumber(
            @PathVariable String mobileNumber) {

        return customerService.getCustomerByMobileNumber(
                mobileNumber);
    }

    @GetMapping("/gender/{gender}")
    public List<CustomerDTO> getCustomersByGender(
            @PathVariable String gender) {

        return customerService.getCustomersByGender(gender);
    }

    @GetMapping("/page")
    public Page<CustomerDTO> getCustomersWithPagination(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size,
            @RequestParam(defaultValue = "customerId") String sortBy) {

        return customerService.getCustomersWithPagination(
                page,
                size,
                sortBy);
    }
}