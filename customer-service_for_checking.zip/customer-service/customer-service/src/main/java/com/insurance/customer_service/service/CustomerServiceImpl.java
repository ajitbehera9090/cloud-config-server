package com.insurance.customer_service.service;


import com.insurance.customer_service.dto.CustomerDTO;
import com.insurance.customer_service.entity.Customer;
import com.insurance.customer_service.exception.CustomerAlreadyExistsException;
import com.insurance.customer_service.exception.CustomerNotFoundException;
import com.insurance.customer_service.repository.CustomerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerServiceImpl
        implements CustomerService {

    private final CustomerRepository customerRepository;

    @Override
    public CustomerDTO createCustomer(
            CustomerDTO customerDTO) {

        if (customerRepository.existsByEmail(
                customerDTO.getEmail())) {

            throw new CustomerAlreadyExistsException(
                    "Customer already exists with email : "
                            + customerDTO.getEmail());
        }

        if (customerRepository.existsByMobileNumber(
                customerDTO.getMobileNumber())) {

            throw new CustomerAlreadyExistsException(
                    "Customer already exists with mobile number : "
                            + customerDTO.getMobileNumber());
        }

        Customer customer =
                dtoToEntity(customerDTO);

        Customer savedCustomer =
                customerRepository.save(customer);

        return entityToDto(savedCustomer);
    }

    @Override
    public CustomerDTO getCustomerById(
            Long customerId) {

        Customer customer =
                customerRepository.findById(customerId)
                        .orElseThrow(() ->
                                new CustomerNotFoundException(
                                        "Customer not found with id : "
                                                + customerId));

        return entityToDto(customer);
    }

    @Override
    public List<CustomerDTO> getAllCustomers() {

        List<Customer> customers =
                customerRepository.findAll();

        List<CustomerDTO> dtoList =
                new ArrayList<>();

        for (Customer customer : customers) {

            dtoList.add(entityToDto(customer));
        }

        return dtoList;
    }

    @Override
    public CustomerDTO updateCustomer(
            Long customerId,
            CustomerDTO customerDTO) {

        Customer customer =
                customerRepository.findById(customerId)
                        .orElseThrow(() ->
                                new CustomerNotFoundException(
                                        "Customer not found with id : "
                                                + customerId));

        customer.setFirstName(
                customerDTO.getFirstName());

        customer.setLastName(
                customerDTO.getLastName());

        customer.setEmail(
                customerDTO.getEmail());

        customer.setMobileNumber(
                customerDTO.getMobileNumber());

        customer.setDateOfBirth(
                customerDTO.getDateOfBirth());

        customer.setGender(
                customerDTO.getGender());

        customer.setAddress(
                customerDTO.getAddress());

        Customer updatedCustomer =
                customerRepository.save(customer);

        return entityToDto(updatedCustomer);
    }

    @Override
    public void deleteCustomer(
            Long customerId) {

        Customer customer =
                customerRepository.findById(customerId)
                        .orElseThrow(() ->
                                new CustomerNotFoundException(
                                        "Customer not found with id : "
                                                + customerId));

        customerRepository.delete(customer);
    }

    @Override
    public CustomerDTO getCustomerByEmail(
            String email) {

        Customer customer =
                customerRepository.findByEmail(email);

        if (customer == null) {

            throw new CustomerNotFoundException(
                    "Customer not found with email : "
                            + email);
        }

        return entityToDto(customer);
    }

    @Override
    public CustomerDTO getCustomerByMobileNumber(
            String mobileNumber) {

        Customer customer =
                customerRepository.findByMobileNumber(
                        mobileNumber);

        if (customer == null) {

            throw new CustomerNotFoundException(
                    "Customer not found with mobile number : "
                            + mobileNumber);
        }

        return entityToDto(customer);
    }

    @Override
    public List<CustomerDTO> getCustomersByGender(
            String gender) {

        List<Customer> customers =
                customerRepository.findByGender(gender);

        List<CustomerDTO> dtoList =
                new ArrayList<>();

        for (Customer customer : customers) {

            dtoList.add(entityToDto(customer));
        }

        return dtoList;
    }

    @Override
    public Page<CustomerDTO> getCustomersWithPagination(
            int page,
            int size,
            String sortBy) {

        Pageable pageable =
                PageRequest.of(
                        page,
                        size,
                        Sort.by(sortBy));

        Page<Customer> customerPage =
                customerRepository.findAll(pageable);

        return customerPage.map(this::entityToDto);
    }

    /*
     * DTO -> Entity
     */
    private Customer dtoToEntity(
            CustomerDTO dto) {

        Customer customer = new Customer();

        customer.setCustomerId(
                dto.getCustomerId());

        customer.setFirstName(
                dto.getFirstName());

        customer.setLastName(
                dto.getLastName());

        customer.setEmail(
                dto.getEmail());

        customer.setMobileNumber(
                dto.getMobileNumber());

        customer.setDateOfBirth(
                dto.getDateOfBirth());

        customer.setGender(
                dto.getGender());

        customer.setAddress(
                dto.getAddress());

        return customer;
    }

    /*
     * Entity -> DTO
     */
    private CustomerDTO entityToDto(
            Customer customer) {

        CustomerDTO dto =
                new CustomerDTO();

        dto.setCustomerId(
                customer.getCustomerId());

        dto.setFirstName(
                customer.getFirstName());

        dto.setLastName(
                customer.getLastName());

        dto.setEmail(
                customer.getEmail());

        dto.setMobileNumber(
                customer.getMobileNumber());

        dto.setDateOfBirth(
                customer.getDateOfBirth());

        dto.setGender(
                customer.getGender());

        dto.setAddress(
                customer.getAddress());

        return dto;
    }
}