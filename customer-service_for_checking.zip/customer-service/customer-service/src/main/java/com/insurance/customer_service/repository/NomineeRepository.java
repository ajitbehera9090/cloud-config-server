package com.insurance.customer_service.repository;

import com.insurance.customer_service.entity.Nominee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NomineeRepository
        extends JpaRepository<Nominee, Long> {

}