package com.insurance.customer_service.exception;

public class InvalidCustomerRequestException extends RuntimeException {


    public InvalidCustomerRequestException(String message) {
        super(message);
    }


}
