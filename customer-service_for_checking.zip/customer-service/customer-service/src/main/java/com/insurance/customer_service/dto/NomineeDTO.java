package com.insurance.customer_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NomineeDTO {

    private Long nomineeId;

    @NotBlank(message = "Nominee name is required")
    private String nomineeName;

    private String relation;

    private Integer age;
}