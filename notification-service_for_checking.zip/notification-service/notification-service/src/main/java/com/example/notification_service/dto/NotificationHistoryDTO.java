package com.example.notification_service.dto;


import com.example.notification_service.entity.NotificationStatus;
import com.example.notification_service.entity.NotificationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationHistoryDTO {

    private Long notificationId;

    private String recipientEmail;

    private String subject;

    private NotificationType notificationType;

    private NotificationStatus status;

    private LocalDateTime sentAt;

}