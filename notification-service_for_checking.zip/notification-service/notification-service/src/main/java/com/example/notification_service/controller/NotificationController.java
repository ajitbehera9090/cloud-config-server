package com.example.notification_service.controller;


import com.example.notification_service.dto.NotificationDTO;
import com.example.notification_service.dto.NotificationHistoryDTO;
import com.example.notification_service.dto.NotificationRequest;
import com.example.notification_service.service.NotificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notifications")
@RequiredArgsConstructor
public class NotificationController {

    private final NotificationService notificationService;

    /**
     * Send Notification
     */
    @PostMapping("/send")
    public ResponseEntity<NotificationDTO> sendNotification(
            @Valid @RequestBody NotificationRequest request) {

        return ResponseEntity.ok(
                notificationService.sendNotification(request));

    }

    /**
     * Get Notification By Id
     */
    @GetMapping("/{notificationId}")
    public ResponseEntity<NotificationDTO> getNotificationById(
            @PathVariable Long notificationId) {

        return ResponseEntity.ok(
                notificationService.getNotificationById(notificationId));

    }

    /**
     * Get All Notifications
     */
    @GetMapping
    public ResponseEntity<List<NotificationDTO>> getAllNotifications() {

        return ResponseEntity.ok(
                notificationService.getAllNotifications());

    }

    /**
     * Get Notifications By Customer
     */
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<NotificationHistoryDTO>>
    getNotificationsByCustomer(
            @PathVariable Long customerId) {

        return ResponseEntity.ok(
                notificationService.getNotificationsByCustomer(customerId));

    }

    /**
     * Get Notifications By Email
     */
    @GetMapping("/email")
    public ResponseEntity<List<NotificationDTO>>
    getNotificationsByEmail(
            @RequestParam String email) {

        return ResponseEntity.ok(
                notificationService.getNotificationsByEmail(email));

    }

    /**
     * Delete Notification
     */
    @DeleteMapping("/{notificationId}")
    public ResponseEntity<String> deleteNotification(
            @PathVariable Long notificationId) {

        notificationService.deleteNotification(notificationId);

        return ResponseEntity.ok(
                "Notification deleted successfully.");

    }

}