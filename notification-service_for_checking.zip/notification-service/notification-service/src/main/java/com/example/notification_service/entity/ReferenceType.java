package com.example.notification_service.entity;

public enum ReferenceType {

    CUSTOMER,

    POLICY,

    PAYMENT,

    CLAIM,

    DOCUMENT

}