package com.example.notification_service.dto;


import com.example.notification_service.dto.EmailAttachmentDTO;
import com.example.notification_service.entity.NotificationType;
import com.example.notification_service.entity.ReferenceType;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationRequest {

    private Long customerId;

    private Long referenceId;

    private ReferenceType referenceType;

    @Email
    @NotBlank
    private String recipientEmail;

    private String recipientName;

    @NotBlank
    private String subject;

    @NotBlank
    private String message;

    private NotificationType notificationType;

    @Valid
    private List<EmailAttachmentDTO> attachments;

}