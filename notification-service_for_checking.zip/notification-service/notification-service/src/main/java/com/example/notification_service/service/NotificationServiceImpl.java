package com.example.notification_service.service;

import com.example.notification_service.client.CustomerFeignClient;
import com.example.notification_service.dto.CustomerDTO;
import com.example.notification_service.dto.NotificationDTO;
import com.example.notification_service.dto.NotificationHistoryDTO;
import com.example.notification_service.dto.NotificationRequest;
import com.example.notification_service.entity.Notification;
import com.example.notification_service.entity.NotificationStatus;
import com.example.notification_service.exception.NotificationNotFoundException;
import com.example.notification_service.mapper.NotificationMapper;
import com.example.notification_service.repository.NotificationRepository;
import com.example.notification_service.util.EmailTemplateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class NotificationServiceImpl
        implements NotificationService {

    private final NotificationRepository notificationRepository;

    private final NotificationMapper notificationMapper;

    private final EmailService emailService;

    private final CustomerFeignClient customerFeignClient;

    private final EmailTemplateUtil emailTemplateUtil;

    @Override
    public NotificationDTO sendNotification(
            NotificationRequest request) {

        log.info("Sending notification to {}",
                request.getRecipientEmail());

        /*
         * Validate Customer
         */
        CustomerDTO customer =
                customerFeignClient.getCustomerById(
                        request.getCustomerId());

        if (customer == null) {

            throw new NotificationNotFoundException(
                    "Customer not found.");

        }

        /*
         * Build Email Template
         */
        request.setMessage(

                emailTemplateUtil.generateMessage(

                        request.getNotificationType(),

                        customer,

                        request));

        /*
         * Create Entity
         */
        Notification notification =
                notificationMapper.toEntity(request);

        notification.setStatus(
                NotificationStatus.PENDING);
        try {

            /*
             * Send Email
             */
            emailService.sendEmail(request);

            /*
             * Update Status
             */
            notification.setStatus(
                    NotificationStatus.SENT);

            notification.setSentAt(
                    LocalDateTime.now());

            log.info(
                    "Email sent successfully to {}",
                    request.getRecipientEmail());

        } catch (Exception ex) {

            log.error(
                    "Unable to send email : {}",
                    ex.getMessage());

            notification.setStatus(
                    NotificationStatus.FAILED);

            notification.setErrorMessage(
                    ex.getMessage());

        }
        /*
         * Save Notification History
         */
        Notification savedNotification =
                notificationRepository.save(notification);

        log.info(
                "Notification saved with id : {}",
                savedNotification.getNotificationId());

        return notificationMapper.toDTO(
                savedNotification);

    }

    @Override
    @Transactional(readOnly = true)
    public NotificationDTO getNotificationById(
            Long notificationId) {

        log.info("Fetching notification with id : {}",
                notificationId);

        Notification notification =
                notificationRepository.findById(notificationId)
                        .orElseThrow(() ->
                                new NotificationNotFoundException(
                                        "Notification not found with id : "
                                                + notificationId));

        return notificationMapper.toDTO(notification);

    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDTO> getAllNotifications() {

        log.info("Fetching all notifications.");

        return notificationRepository.findAll()
                .stream()
                .map(notificationMapper::toDTO)
                .toList();

    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationHistoryDTO> getNotificationsByCustomer(
            Long customerId) {

        log.info("Fetching notifications for customer : {}",
                customerId);

        return notificationRepository
                .findByCustomerIdOrderByCreatedAtDesc(customerId)
                .stream()
                .map(notificationMapper::toHistoryDTO)
                .toList();

    }

    @Override
    @Transactional(readOnly = true)
    public List<NotificationDTO> getNotificationsByEmail(
            String email) {

        log.info("Fetching notifications for email : {}",
                email);

        return notificationRepository
                .findByRecipientEmail(email)
                .stream()
                .map(notificationMapper::toDTO)
                .toList();

    }

    @Override
    public void deleteNotification(
            Long notificationId) {

        log.info("Deleting notification : {}",
                notificationId);

        Notification notification =
                notificationRepository.findById(notificationId)
                        .orElseThrow(() ->
                                new NotificationNotFoundException(
                                        "Notification not found with id : "
                                                + notificationId));

        notificationRepository.delete(notification);

        log.info("Notification deleted successfully.");

    }


}

