package com.example.notification_service.service;


import com.example.notification_service.dto.NotificationDTO;
import com.example.notification_service.dto.NotificationHistoryDTO;
import com.example.notification_service.dto.NotificationRequest;

import java.util.List;

public interface NotificationService {

    /**
     * Send notification.
     */
    NotificationDTO sendNotification(
            NotificationRequest request);

    /**
     * Get notification by id.
     */
    NotificationDTO getNotificationById(
            Long notificationId);

    /**
     * Get all notifications.
     */
    List<NotificationDTO> getAllNotifications();

    /**
     * Get notifications by customer.
     */
    List<NotificationHistoryDTO> getNotificationsByCustomer(
            Long customerId);

    /**
     * Get notifications by email.
     */
    List<NotificationDTO> getNotificationsByEmail(
            String email);

    /**
     * Delete notification history.
     */
    void deleteNotification(
            Long notificationId);

}