package com.example.notification_service.repository;


import com.example.notification_service.entity.Notification;
import com.example.notification_service.entity.NotificationStatus;
import com.example.notification_service.entity.NotificationType;
import com.example.notification_service.entity.ReferenceType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotificationRepository
        extends JpaRepository<Notification, Long> {

    List<Notification> findByCustomerId(Long customerId);

    List<Notification> findByRecipientEmail(String recipientEmail);

    List<Notification> findByStatus(NotificationStatus status);

    List<Notification> findByNotificationType(NotificationType notificationType);

    List<Notification> findByReferenceTypeAndReferenceId(
            ReferenceType referenceType,
            Long referenceId);

    List<Notification> findByCustomerIdOrderByCreatedAtDesc(
            Long customerId);

    List<Notification> findByStatusOrderByCreatedAtDesc(
            NotificationStatus status);

}