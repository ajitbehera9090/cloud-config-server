package com.example.notification_service.exception;

public class NotificationDeliveryException
        extends RuntimeException {

    public NotificationDeliveryException(
            String message) {

        super(message);
    }
}