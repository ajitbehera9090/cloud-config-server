package com.example.notification_service.mapper;


import com.example.notification_service.dto.NotificationDTO;
import com.example.notification_service.dto.NotificationHistoryDTO;
import com.example.notification_service.dto.NotificationRequest;
import com.example.notification_service.entity.Notification;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface NotificationMapper {

    /**
     * Request -> Entity
     */
    @Mapping(target = "notificationId", ignore = true)
    @Mapping(target = "status", ignore = true)
    @Mapping(target = "attachmentPath", ignore = true)
    @Mapping(target = "attachmentName", ignore = true)
    @Mapping(target = "errorMessage", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    @Mapping(target = "updatedAt", ignore = true)
    @Mapping(target = "sentAt", ignore = true)
    Notification toEntity(NotificationRequest request);

    /**
     * Entity -> DTO
     */
    NotificationDTO toDTO(Notification notification);

    /**
     * Entity -> History DTO
     */
    NotificationHistoryDTO toHistoryDTO(Notification notification);

}