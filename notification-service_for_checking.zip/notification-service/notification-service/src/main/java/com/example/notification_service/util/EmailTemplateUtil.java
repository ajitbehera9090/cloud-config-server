package com.example.notification_service.util;


import com.example.notification_service.dto.CustomerDTO;
import com.example.notification_service.dto.NotificationRequest;
import com.example.notification_service.entity.NotificationType;
import org.springframework.stereotype.Component;

@Component
public class EmailTemplateUtil {

    public String generateMessage(
            NotificationType notificationType,
            CustomerDTO customer,
            NotificationRequest request) {

        String customerName = customer.getFirstName() + " " + customer.getLastName();

        return switch (notificationType) {

            case WELCOME ->
                    """
                    Dear %s,

                    Welcome to ABC Insurance.

                    We are delighted to have you as our valued customer.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case POLICY_CREATED ->
                    """
                    Dear %s,

                    Your insurance policy has been created successfully.

                    Please find the policy document attached.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case PAYMENT_SUCCESS ->
                    """
                    Dear %s,

                    Your premium payment has been received successfully.

                    Thank you for your payment.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case PAYMENT_FAILED ->
                    """
                    Dear %s,

                    Unfortunately, your payment could not be processed.

                    Please try again.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case CLAIM_SUBMITTED ->
                    """
                    Dear %s,

                    Your claim has been submitted successfully.

                    Our team will review it shortly.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case CLAIM_APPROVED ->
                    """
                    Dear %s,

                    Congratulations!

                    Your insurance claim has been approved.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case CLAIM_REJECTED ->
                    """
                    Dear %s,

                    We regret to inform you that your claim has been rejected.

                    Please contact support for more details.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case DOCUMENT_SHARED ->
                    """
                    Dear %s,

                    The requested document has been shared with you.

                    Please find it attached.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case POLICY_RENEWAL ->
                    """
                    Dear %s,

                    Your policy is due for renewal.

                    Please renew it before the expiry date.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case PASSWORD_RESET ->
                    """
                    Dear %s,

                    Your password reset request has been received.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName);

            case OTP ->
                    """
                    Dear %s,

                    Your OTP is:

                    %s

                    This OTP is valid for 10 minutes.

                    Regards,
                    ABC Insurance Team
                    """.formatted(customerName, request.getMessage());
        };

    }

}