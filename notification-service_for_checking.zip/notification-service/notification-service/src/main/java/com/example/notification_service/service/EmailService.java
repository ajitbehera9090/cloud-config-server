package com.example.notification_service.service;


import com.example.notification_service.dto.NotificationRequest;

public interface EmailService {

    /**
     * Sends email.
     */
    void sendEmail(NotificationRequest request);

}