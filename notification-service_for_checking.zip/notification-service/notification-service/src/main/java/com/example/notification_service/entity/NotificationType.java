package com.example.notification_service.entity;

public enum NotificationType {

    WELCOME,

    POLICY_CREATED,

    POLICY_RENEWAL,

    PAYMENT_SUCCESS,

    PAYMENT_FAILED,

    CLAIM_SUBMITTED,

    CLAIM_APPROVED,

    CLAIM_REJECTED,

    DOCUMENT_SHARED,

    PASSWORD_RESET,

    OTP

}