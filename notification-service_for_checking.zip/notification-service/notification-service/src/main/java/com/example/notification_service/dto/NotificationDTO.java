package com.example.notification_service.dto;


import com.example.notification_service.entity.NotificationStatus;
import com.example.notification_service.entity.NotificationType;
import com.example.notification_service.entity.ReferenceType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NotificationDTO {

    private Long notificationId;

    private Long customerId;

    private Long referenceId;

    private ReferenceType referenceType;

    private String recipientEmail;

    private String recipientName;

    private String subject;

    private String message;

    private NotificationType notificationType;

    private NotificationStatus status;

    private String attachmentPath;

    private String attachmentName;

    private String errorMessage;

    private LocalDateTime createdAt;

    private LocalDateTime sentAt;

}