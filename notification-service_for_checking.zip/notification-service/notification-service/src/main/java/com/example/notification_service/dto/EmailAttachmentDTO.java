package com.example.notification_service.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmailAttachmentDTO {

    /**
     * Original file name.
     */
    private String fileName;

    /**
     * Physical file path.
     */
    private String filePath;

    /**
     * MIME Type.
     */
    private String contentType;

}