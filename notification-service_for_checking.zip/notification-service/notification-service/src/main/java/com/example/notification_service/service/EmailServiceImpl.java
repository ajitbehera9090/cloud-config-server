package com.example.notification_service.service;


import com.example.notification_service.dto.EmailAttachmentDTO;
import com.example.notification_service.dto.NotificationRequest;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
@RequiredArgsConstructor
@Slf4j
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;

    @Override
    public void sendEmail(NotificationRequest request) {

        try {

            MimeMessage mimeMessage =
                    mailSender.createMimeMessage();

            MimeMessageHelper helper =
                    new MimeMessageHelper(
                            mimeMessage,
                            true);

            helper.setTo(request.getRecipientEmail());

            helper.setSubject(request.getSubject());

            helper.setText(request.getMessage(), false);

            if (request.getAttachments() != null) {

                for (EmailAttachmentDTO attachment :
                        request.getAttachments()) {

                    File file =
                            new File(attachment.getFilePath());

                    if (file.exists()) {

                        helper.addAttachment(
                                attachment.getFileName(),
                                new FileSystemResource(file));

                    }

                }

            }

            mailSender.send(mimeMessage);

            log.info(
                    "Email sent successfully to {}",
                    request.getRecipientEmail());

        } catch (MessagingException | MailException ex) {

            log.error(
                    "Failed to send email : {}",
                    ex.getMessage());

            throw new RuntimeException(
                    "Unable to send email.",
                    ex);

        }

    }

}