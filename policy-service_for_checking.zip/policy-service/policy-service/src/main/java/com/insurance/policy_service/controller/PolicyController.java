package com.insurance.policy_service.controller;


import com.insurance.policy_service.dto.PolicyDTO;
import com.insurance.policy_service.service.PolicyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/policies")
@RequiredArgsConstructor
public class PolicyController {

    private final PolicyService policyService;

    @PostMapping
    public PolicyDTO createPolicy(
            @Valid @RequestBody PolicyDTO policyDTO) {

        return policyService.createPolicy(policyDTO);
    }

    @GetMapping("/{id}")
    public PolicyDTO getPolicyById(
            @PathVariable Long id) {

        return policyService.getPolicyById(id);
    }

    @GetMapping
    public List<PolicyDTO> getAllPolicies() {

        return policyService.getAllPolicies();
    }

    @PutMapping("/{id}")
    public PolicyDTO updatePolicy(
            @PathVariable Long id,
            @Valid @RequestBody PolicyDTO policyDTO) {

        return policyService.updatePolicy(id, policyDTO);
    }

    @DeleteMapping("/{id}")
    public String deletePolicy(
            @PathVariable Long id) {

        policyService.deletePolicy(id);

        return "Policy deleted successfully";
    }

    @GetMapping("/number/{policyNumber}")
    public PolicyDTO getPolicyByPolicyNumber(
            @PathVariable String policyNumber) {

        return policyService.getPolicyByPolicyNumber(
                policyNumber);
    }

    @GetMapping("/customer/{customerId}")
    public List<PolicyDTO> getPoliciesByCustomerId(
            @PathVariable Long customerId) {

        return policyService.getPoliciesByCustomerId(
                customerId);
    }

    @GetMapping("/type/{policyType}")
    public List<PolicyDTO> getPoliciesByType(
            @PathVariable String policyType) {

        return policyService.getPoliciesByPolicyType(
                policyType);
    }

    @GetMapping("/search")
    public Page<PolicyDTO> searchPolicies(
            @RequestParam String policyType,
            @RequestParam int page,
            @RequestParam int size,
            @RequestParam String sortBy) {

        return policyService
                .getPoliciesByTypeWithPagination(
                        policyType,
                        page,
                        size,
                        sortBy);
    }
}