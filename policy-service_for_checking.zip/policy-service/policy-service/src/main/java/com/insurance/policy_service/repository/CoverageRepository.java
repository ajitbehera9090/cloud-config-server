package com.insurance.policy_service.repository;


import com.insurance.policy_service.entity.Coverage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoverageRepository
        extends JpaRepository<Coverage, Long> {
}