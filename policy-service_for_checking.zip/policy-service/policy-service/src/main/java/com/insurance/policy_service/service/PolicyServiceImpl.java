package com.insurance.policy_service.service;


import com.insurance.policy_service.client.CustomerFeignClient;
import com.insurance.policy_service.dto.CoverageDTO;
import com.insurance.policy_service.dto.CustomerDTO;
import com.insurance.policy_service.dto.PolicyDTO;
import com.insurance.policy_service.dto.PolicyDocumentDTO;
import com.insurance.policy_service.entity.Coverage;
import com.insurance.policy_service.entity.Policy;
import com.insurance.policy_service.entity.PolicyDocument;
import com.insurance.policy_service.exception.CustomerEligibilityException;
import com.insurance.policy_service.exception.PolicyAlreadyExistsException;
import com.insurance.policy_service.exception.PolicyNotFoundException;
import com.insurance.policy_service.repository.PolicyRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class PolicyServiceImpl implements PolicyService {


    private final PolicyRepository policyRepository;
    private final CustomerFeignClient customerFeignClient;

    @Override
    public PolicyDTO createPolicy(PolicyDTO policyDTO) {

        if (policyRepository.existsByPolicyNumber(
                policyDTO.getPolicyNumber())) {

            throw new PolicyAlreadyExistsException(
                    "Policy already exists with policy number : "
                            + policyDTO.getPolicyNumber());
        }

        CustomerDTO customer =
                customerFeignClient.getCustomerById(
                        policyDTO.getCustomerId());

        if (customer == null) {

            throw new CustomerEligibilityException(
                    "Customer is not eligible for policy issuance");
        }

        Policy policy = dtoToEntity(policyDTO);

        Policy savedPolicy =
                policyRepository.save(policy);

        return entityToDto(savedPolicy);
    }

    @Override
    public PolicyDTO getPolicyById(Long policyId) {

        Policy policy = policyRepository.findById(policyId)
                .orElseThrow(() ->
                        new PolicyNotFoundException(
                                "Policy not found with id : "
                                        + policyId));

        return entityToDto(policy);
    }

    @Override
    public List<PolicyDTO> getAllPolicies() {

        List<Policy> policies =
                policyRepository.findAll();

        List<PolicyDTO> dtoList =
                new ArrayList<>();

        for (Policy policy : policies) {

            dtoList.add(entityToDto(policy));
        }

        return dtoList;
    }

    @Override
    public PolicyDTO updatePolicy(
            Long policyId,
            PolicyDTO policyDTO) {

        Policy existingPolicy =
                policyRepository.findById(policyId)
                        .orElseThrow(() ->
                                new PolicyNotFoundException(
                                        "Policy not found with id : "
                                                + policyId));

        CustomerDTO customer =
                customerFeignClient.getCustomerById(
                        policyDTO.getCustomerId());

        if (customer == null) {

            throw new CustomerEligibilityException(
                    "Customer is not eligible for policy update");
        }

        existingPolicy.setPolicyNumber(
                policyDTO.getPolicyNumber());

        existingPolicy.setPolicyType(
                policyDTO.getPolicyType());

        existingPolicy.setPremiumAmount(
                policyDTO.getPremiumAmount());

        existingPolicy.setSumAssured(
                policyDTO.getSumAssured());

        existingPolicy.setCustomerId(
                policyDTO.getCustomerId());

        /*
         * Coverage Update
         * orphanRemoval = true
         */
        existingPolicy.getCoverages().clear();

        if (policyDTO.getCoverages() != null) {

            for (CoverageDTO coverageDTO
                    : policyDTO.getCoverages()) {

                Coverage coverage = new Coverage();

                coverage.setCoverageName(
                        coverageDTO.getCoverageName());

                coverage.setCoverageLimit(
                        coverageDTO.getCoverageLimit());

                coverage.setPolicy(existingPolicy);

                existingPolicy.getCoverages()
                        .add(coverage);
            }
        }

        /*
         * Document Update
         * orphanRemoval = true
         */
        existingPolicy.getDocuments().clear();

        if (policyDTO.getDocuments() != null) {

            for (PolicyDocumentDTO documentDTO
                    : policyDTO.getDocuments()) {

                PolicyDocument document =
                        new PolicyDocument();

                document.setDocumentName(
                        documentDTO.getDocumentName());

                document.setDocumentType(
                        documentDTO.getDocumentType());

                document.setPolicy(existingPolicy);

                existingPolicy.getDocuments()
                        .add(document);
            }
        }

        Policy updatedPolicy =
                policyRepository.save(existingPolicy);

        return entityToDto(updatedPolicy);
    }

    @Override
    public void deletePolicy(Long policyId) {

        Policy policy =
                policyRepository.findById(policyId)
                        .orElseThrow(() ->
                                new PolicyNotFoundException(
                                        "Policy not found with id : "
                                                + policyId));

        policyRepository.delete(policy);
    }

    @Override
    public PolicyDTO getPolicyByPolicyNumber(
            String policyNumber) {

        Policy policy =
                policyRepository.findByPolicyNumber(
                        policyNumber);

        if (policy == null) {

            throw new PolicyNotFoundException(
                    "Policy not found with policy number : "
                            + policyNumber);
        }

        return entityToDto(policy);
    }

    @Override
    public List<PolicyDTO> getPoliciesByCustomerId(
            Long customerId) {

        List<Policy> policies =
                policyRepository.findByCustomerId(
                        customerId);

        List<PolicyDTO> dtoList =
                new ArrayList<>();

        for (Policy policy : policies) {

            dtoList.add(entityToDto(policy));
        }

        return dtoList;
    }

    @Override
    public List<PolicyDTO> getPoliciesByPolicyType(
            String policyType) {

        List<Policy> policies =
                policyRepository.findByPolicyType(
                        policyType);

        List<PolicyDTO> dtoList =
                new ArrayList<>();

        for (Policy policy : policies) {

            dtoList.add(entityToDto(policy));
        }

        return dtoList;
    }

    @Override
    public Page<PolicyDTO> getPoliciesByTypeWithPagination(
            String policyType,
            int page,
            int size,
            String sortBy) {

        Pageable pageable =
                PageRequest.of(
                        page,
                        size,
                        Sort.by(sortBy));

        Page<Policy> policyPage =
                policyRepository.findByPolicyType(
                        policyType,
                        pageable);

        return policyPage.map(this::entityToDto);
    }

    /*
     * DTO -> Entity Mapping
     */
    private Policy dtoToEntity(
            PolicyDTO dto) {

        Policy policy = new Policy();

        policy.setPolicyId(dto.getPolicyId());

        policy.setPolicyNumber(
                dto.getPolicyNumber());

        policy.setPolicyType(
                dto.getPolicyType());

        policy.setPremiumAmount(
                dto.getPremiumAmount());

        policy.setSumAssured(
                dto.getSumAssured());

        policy.setCustomerId(
                dto.getCustomerId());

        if (dto.getCoverages() != null) {

            for (CoverageDTO coverageDTO
                    : dto.getCoverages()) {

                Coverage coverage = new Coverage();

                coverage.setCoverageName(
                        coverageDTO.getCoverageName());

                coverage.setCoverageLimit(
                        coverageDTO.getCoverageLimit());

                coverage.setPolicy(policy);

                policy.getCoverages()
                        .add(coverage);
            }
        }

        if (dto.getDocuments() != null) {

            for (PolicyDocumentDTO documentDTO
                    : dto.getDocuments()) {

                PolicyDocument document =
                        new PolicyDocument();

                document.setDocumentName(
                        documentDTO.getDocumentName());

                document.setDocumentType(
                        documentDTO.getDocumentType());

                document.setPolicy(policy);

                policy.getDocuments()
                        .add(document);
            }
        }

        return policy;
    }

    /*
     * Entity -> DTO Mapping
     */
    private PolicyDTO entityToDto(
            Policy policy) {

        PolicyDTO dto = new PolicyDTO();

        dto.setPolicyId(policy.getPolicyId());

        dto.setPolicyNumber(
                policy.getPolicyNumber());

        dto.setPolicyType(
                policy.getPolicyType());

        dto.setPremiumAmount(
                policy.getPremiumAmount());

        dto.setSumAssured(
                policy.getSumAssured());

        dto.setCustomerId(
                policy.getCustomerId());

        List<CoverageDTO> coverageDTOList =
                new ArrayList<>();

        for (Coverage coverage
                : policy.getCoverages()) {

            CoverageDTO coverageDTO =
                    new CoverageDTO();

            coverageDTO.setCoverageId(
                    coverage.getCoverageId());

            coverageDTO.setCoverageName(
                    coverage.getCoverageName());

            coverageDTO.setCoverageLimit(
                    coverage.getCoverageLimit());

            coverageDTOList.add(coverageDTO);
        }

        dto.setCoverages(coverageDTOList);

        List<PolicyDocumentDTO> documentDTOList =
                new ArrayList<>();

        for (PolicyDocument document
                : policy.getDocuments()) {

            PolicyDocumentDTO documentDTO =
                    new PolicyDocumentDTO();

            documentDTO.setDocumentId(
                    document.getDocumentId());

            documentDTO.setDocumentName(
                    document.getDocumentName());

            documentDTO.setDocumentType(
                    document.getDocumentType());

            documentDTOList.add(documentDTO);
        }

        dto.setDocuments(documentDTOList);

        return dto;
    }


}
