package com.insurance.policy_service.client;


import com.insurance.policy_service.dto.DocumentRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "document-service")
public interface DocumentFeignClient {

    @PostMapping("/documents/generate/policy")
    DocumentResponse generatePolicyDocument(
            @RequestBody DocumentRequest request);

}