package com.insurance.policy_service.exception;

public class PolicyAlreadyExistsException extends RuntimeException {

    public PolicyAlreadyExistsException(String message) {
        super(message);
    }
}