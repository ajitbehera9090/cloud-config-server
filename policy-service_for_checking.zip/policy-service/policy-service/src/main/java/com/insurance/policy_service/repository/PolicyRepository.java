package com.insurance.policy_service.repository;


import com.insurance.policy_service.entity.Policy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PolicyRepository extends JpaRepository<Policy, Long> {

    boolean existsByPolicyNumber(String policyNumber);

    Policy findByPolicyNumber(String policyNumber);

    List<Policy> findByCustomerId(Long customerId);

    List<Policy> findByPolicyType(String policyType);

    Page<Policy> findByPolicyType(
            String policyType,
            Pageable pageable
    );
}