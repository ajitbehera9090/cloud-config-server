package com.insurance.policy_service.repository;


import com.insurance.policy_service.entity.PolicyDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PolicyDocumentRepository
        extends JpaRepository<PolicyDocument, Long> {
}