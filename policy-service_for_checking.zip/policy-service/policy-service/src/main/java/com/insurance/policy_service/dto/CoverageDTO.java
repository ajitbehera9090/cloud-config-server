package com.insurance.policy_service.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class CoverageDTO {

    private Long coverageId;

    @NotBlank
    private String coverageName;

    @NotNull
    private BigDecimal coverageLimit;
}