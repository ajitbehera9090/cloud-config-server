package com.insurance.policy_service.dto;

import lombok.Data;

@Data
public class CustomerDTO {

    private Long customerId;

    private String firstName;

    private String lastName;

    private String email;

    private String mobile;

    private String address;
}