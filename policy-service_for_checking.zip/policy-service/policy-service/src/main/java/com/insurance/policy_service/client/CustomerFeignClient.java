package com.insurance.policy_service.client;


import com.insurance.policy_service.dto.CustomerDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "CUSTOMER-SERVICE")
public interface CustomerFeignClient {

    @GetMapping("/customers/{id}")
    CustomerDTO getCustomerById(
            @PathVariable("id") Long id);

}