package com.insurance.policy_service.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
public class PolicyDTO {

    private Long policyId;

    @NotNull
    private Long customerId;

    @NotBlank
    private String policyNumber;

    @NotBlank
    private String policyType;

    @NotNull
    private BigDecimal premiumAmount;

    @NotNull
    private BigDecimal sumAssured;

    @Valid
    private List<CoverageDTO> coverages;

    @Valid
    private List<PolicyDocumentDTO> documents;
}