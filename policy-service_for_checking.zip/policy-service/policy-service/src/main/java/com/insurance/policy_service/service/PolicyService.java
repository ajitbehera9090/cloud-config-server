package com.insurance.policy_service.service;


import com.insurance.policy_service.dto.PolicyDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface PolicyService {

    PolicyDTO createPolicy(PolicyDTO policyDTO);

    PolicyDTO getPolicyById(Long policyId);

    List<PolicyDTO> getAllPolicies();

    PolicyDTO updatePolicy(Long policyId,
                           PolicyDTO policyDTO);

    void deletePolicy(Long policyId);

    PolicyDTO getPolicyByPolicyNumber(
            String policyNumber);

    List<PolicyDTO> getPoliciesByCustomerId(
            Long customerId);

    List<PolicyDTO> getPoliciesByPolicyType(
            String policyType);

    Page<PolicyDTO> getPoliciesByTypeWithPagination(
            String policyType,
            int page,
            int size,
            String sortBy);
}