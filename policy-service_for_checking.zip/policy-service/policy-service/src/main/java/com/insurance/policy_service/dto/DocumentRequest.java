package com.insurance.policy_service.dto;

public class DocumentRequest {
}
