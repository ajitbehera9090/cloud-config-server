package com.insurance.policy_service.exception;

public class CustomerEligibilityException extends RuntimeException {


    public CustomerEligibilityException(String message) {
        super(message);
    }


}
