package com.insurance.policy_service.client;


import com.insurance.policy_service.dto.NotificationRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service")
public interface NotificationFeignClient {

    @PostMapping("/notifications/send")
    void sendNotification(
            @RequestBody NotificationRequest request);

}