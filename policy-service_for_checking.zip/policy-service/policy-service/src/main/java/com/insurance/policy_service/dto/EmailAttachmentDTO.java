package com.insurance.policy_service.dto;

public class EmailAttachmentDTO {
}
