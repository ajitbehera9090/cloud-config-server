package com.insurance.policy_service.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PolicyDocumentDTO {

    private Long documentId;

    @NotBlank
    private String documentName;

    @NotBlank
    private String documentType;
}