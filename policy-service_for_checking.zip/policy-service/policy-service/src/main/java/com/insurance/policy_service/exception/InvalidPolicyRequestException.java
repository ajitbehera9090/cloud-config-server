package com.insurance.policy_service.exception;

public class InvalidPolicyRequestException extends RuntimeException {

    public InvalidPolicyRequestException(String message) {
        super(message);
    }
}