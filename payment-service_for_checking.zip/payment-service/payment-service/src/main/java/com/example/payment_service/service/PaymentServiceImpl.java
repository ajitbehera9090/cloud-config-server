
package com.example.payment_service.service;


import com.example.payment_service.client.CustomerFeignClient;
import com.example.payment_service.client.NotificationFeignClient;
import com.example.payment_service.client.PolicyFeignClient;
import com.example.payment_service.dto.CustomerDTO;
import com.example.payment_service.dto.NotificationDTO;
import com.example.payment_service.dto.PaymentDTO;
import com.example.payment_service.dto.PolicyDTO;
import com.example.payment_service.entity.Payment;
import com.example.payment_service.entity.PaymentStatus;
import com.example.payment_service.exception.InvalidPaymentRequestException;
import com.example.payment_service.exception.PaymentAlreadyCompletedException;
import com.example.payment_service.exception.PaymentNotFoundException;
import com.example.payment_service.repository.PaymentRepository;
import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class PaymentServiceImpl implements PaymentService {

    private static final Logger logger =
            LoggerFactory.getLogger(PaymentServiceImpl.class);

    private final PaymentRepository paymentRepository;
    private final CustomerFeignClient customerFeignClient;
    private final PolicyFeignClient policyFeignClient;
    private final NotificationFeignClient notificationFeignClient;

    public PaymentServiceImpl(
            PaymentRepository paymentRepository,
            CustomerFeignClient customerFeignClient,
            PolicyFeignClient policyFeignClient,
            NotificationFeignClient notificationFeignClient) {

        this.paymentRepository = paymentRepository;
        this.customerFeignClient = customerFeignClient;
        this.policyFeignClient = policyFeignClient;
        this.notificationFeignClient = notificationFeignClient;
    }

    /*
    ============================================================
                    MAKE PAYMENT
    ============================================================

    Business Flow

    1. Validate Customer

    2. Validate Policy

    3. Business Validation

    4. Create Payment Entity

    5. Save Payment

    6. Send Notification

    7. Return DTO

    Transaction Behaviour

    - REQUIRED propagation (Default)
    - If any RuntimeException occurs,
      the transaction rolls back.
    ============================================================
    */

    @Override
    @Transactional
    public PaymentDTO makePayment(PaymentDTO dto) {

        logger.info("Starting payment process for Policy Id : {}",
                dto.getPolicyId());

        /*
         ---------------------------------------------------
         Step 1 : Validate Customer
         ---------------------------------------------------
         */
        CustomerDTO customer =
                customerFeignClient.getCustomerById(dto.getCustomerId());

        if (customer == null) {

            logger.error("Customer not found.");

            throw new InvalidPaymentRequestException(
                    "Customer does not exist.");
        }

        logger.info("Customer validation completed.");

        /*
         ---------------------------------------------------
         Step 2 : Validate Policy
         ---------------------------------------------------
         */

        PolicyDTO policy =
                policyFeignClient.getPolicyById(dto.getPolicyId());

        if (policy == null) {

            logger.error("Policy not found.");

            throw new InvalidPaymentRequestException(
                    "Policy does not exist.");
        }

        logger.info("Policy validation completed.");

        /*
         ---------------------------------------------------
         Step 3 : Business Validation
         ---------------------------------------------------
         */

        if (!policy.getPolicyStatus().equalsIgnoreCase("ACTIVE")) {

            throw new InvalidPaymentRequestException(
                    "Only ACTIVE policies can receive payments.");
        }

        if (dto.getAmount()
                .compareTo(policy.getPremiumAmount()) < 0) {

            throw new InvalidPaymentRequestException(
                    "Premium amount is less than required.");
        }

        /*
         ---------------------------------------------------
         Step 4 : Create Payment Entity
         ---------------------------------------------------
         */

        Payment payment = new Payment();

        payment.setCustomerId(dto.getCustomerId());

        payment.setPolicyId(dto.getPolicyId());

        payment.setAmount(dto.getAmount());

        payment.setPaymentMethod(dto.getPaymentMethod());

        payment.setPaymentGateway("FAKE_GATEWAY");

        payment.setGatewayTransactionId(
                UUID.randomUUID().toString());

        payment.setTransactionReference(
                generateTransactionReference());

        payment.setPaymentStatus(
                PaymentStatus.SUCCESS);

        payment.setPaymentDate(
                LocalDateTime.now());

        payment.setRemarks(
                "Insurance premium paid successfully.");

        /*
         ---------------------------------------------------
         Step 5 : Save Payment
         ---------------------------------------------------
         */

        logger.info("Saving payment information.");

        Payment savedPayment =
                paymentRepository.save(payment);

        logger.info("Payment saved successfully.");

        /*
         ---------------------------------------------------
         Step 6 : Send Notification
         ---------------------------------------------------
         */

        NotificationDTO notification =
                new NotificationDTO();

        notification.setCustomerId(customer.getCustomerId());

        notification.setRecipientEmail(customer.getEmail());

        notification.setSubject(
                "Insurance Premium Payment Successful");

        notification.setMessage(

                "Dear "

                        + customer.getFirstName()

                        + ", your premium payment of Rs. "

                        + savedPayment.getAmount()

                        + " has been received successfully."

                        + " Transaction Reference : "

                        + savedPayment.getTransactionReference()

        );

        logger.info("Calling Notification Service.");

        notificationFeignClient.sendNotification(notification);

        logger.info("Notification sent successfully.");

        /*
         ---------------------------------------------------
         Step 7 : Return Response
         ---------------------------------------------------
         */

        return convertToDTO(savedPayment);

    }

    /*
    ============================================================
                    GET PAYMENT BY ID
    ============================================================
    */

    @Override
    public PaymentDTO getPaymentById(Long paymentId) {

        logger.info("Fetching payment details for Payment Id : {}",
                paymentId);

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> {

                    logger.error("Payment not found.");

                    return new PaymentNotFoundException(
                            "Payment not found with Id : " + paymentId);

                });

        logger.info("Payment fetched successfully.");

        return convertToDTO(payment);

    }

    /*
    ============================================================
                    GET ALL PAYMENTS
    ============================================================
    */

    @Override
    public List<PaymentDTO> getAllPayments() {

        logger.info("Fetching all payments.");

        List<Payment> payments =
                paymentRepository.findAll();

        logger.info("Total Payments Found : {}",
                payments.size());

        return payments.stream()

                .map(this::convertToDTO)

                .collect(Collectors.toList());

    }

    /*
    ============================================================
                GET PAYMENTS BY CUSTOMER ID
    ============================================================
    */

    @Override
    public List<PaymentDTO> getPaymentsByCustomerId(
            Long customerId) {

        logger.info(
                "Fetching payments for Customer Id : {}",
                customerId);

        List<Payment> payments =
                paymentRepository.findByCustomerId(customerId);

        if (payments.isEmpty()) {

            logger.warn(
                    "No payments found for Customer Id : {}",
                    customerId);

            throw new PaymentNotFoundException(

                    "No payments found for Customer Id : "

                            + customerId);

        }

        logger.info("{} payments found.",
                payments.size());

        return payments.stream()

                .map(this::convertToDTO)

                .collect(Collectors.toList());

    }

    /*
    ============================================================
                GET PAYMENTS BY POLICY ID
    ============================================================
    */

    @Override
    public List<PaymentDTO> getPaymentsByPolicyId(
            Long policyId) {

        logger.info(
                "Fetching payments for Policy Id : {}",
                policyId);

        List<Payment> payments =
                paymentRepository.findByPolicyId(policyId);

        if (payments.isEmpty()) {

            logger.warn(
                    "No payments found for Policy Id : {}",
                    policyId);

            throw new PaymentNotFoundException(

                    "No payments found for Policy Id : "

                            + policyId);

        }

        logger.info("{} payments found.",
                payments.size());

        return payments.stream()

                .map(this::convertToDTO)

                .collect(Collectors.toList());

    }

    /*
    ============================================================
                GET PAYMENTS BY STATUS
    ============================================================
    */

    @Override
    public List<PaymentDTO> getPaymentsByStatus(
            String paymentStatus) {

        logger.info(
                "Fetching payments by Status : {}",
                paymentStatus);

        PaymentStatus status;

        try {

            status = PaymentStatus.valueOf(
                    paymentStatus.toUpperCase());

        } catch (IllegalArgumentException ex) {

            throw new InvalidPaymentRequestException(

                    "Invalid Payment Status : "

                            + paymentStatus);

        }

        List<Payment> payments =
                paymentRepository.findByPaymentStatus(status);

        if (payments.isEmpty()) {

            throw new PaymentNotFoundException(

                    "No payments found with Status : "

                            + paymentStatus);

        }

        logger.info("{} payment(s) found.",
                payments.size());

        return payments.stream()

                .map(this::convertToDTO)

                .collect(Collectors.toList());

    }


    /*
    ============================================================
                    UPDATE PAYMENT
    ============================================================
    */

    @Override
    @Transactional
    public PaymentDTO updatePayment(Long paymentId,
                                    PaymentDTO dto) {

        logger.info("Updating payment with Id : {}", paymentId);

        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new PaymentNotFoundException(
                        "Payment not found with Id : " + paymentId));

        /*
         * Once a payment is SUCCESS,
         * it should not be modified.
         */
        if (payment.getPaymentStatus() == PaymentStatus.SUCCESS) {

            throw new PaymentAlreadyCompletedException(
                    "Successful payment cannot be modified.");
        }

        payment.setAmount(dto.getAmount());
        payment.setPaymentMethod(dto.getPaymentMethod());

        if (dto.getRemarks() != null) {
            payment.setRemarks(dto.getRemarks());
        }

        if (dto.getPaymentStatus() != null) {

            payment.setPaymentStatus(
                    PaymentStatus.valueOf(
                            dto.getPaymentStatus().toUpperCase()));
        }

        Payment updatedPayment =
                paymentRepository.save(payment);

        logger.info("Payment updated successfully.");

        return convertToDTO(updatedPayment);

    }

    /*
    ============================================================
                    DELETE PAYMENT
    ============================================================

    Note:

    In real Banking/Insurance applications,
    payments are usually NOT deleted.

    They are marked as

    CANCELLED

    or

    REFUNDED

    We are implementing delete only
    because this project also teaches CRUD.
    ============================================================
    */

    @Override
    @Transactional
    public void deletePayment(Long paymentId) {

        logger.info("Deleting payment : {}", paymentId);

        Payment payment =
                paymentRepository.findById(paymentId)

                        .orElseThrow(() ->
                                new PaymentNotFoundException(
                                        "Payment not found."));

        paymentRepository.delete(payment);

        logger.info("Payment deleted successfully.");

    }

    /*
    ============================================================
                    ENTITY -> DTO
    ============================================================
    */

    private PaymentDTO convertToDTO(Payment payment) {

        PaymentDTO dto = new PaymentDTO();

        dto.setPaymentId(payment.getPaymentId());

        dto.setCustomerId(payment.getCustomerId());

        dto.setPolicyId(payment.getPolicyId());

        dto.setAmount(payment.getAmount());

        dto.setPaymentMethod(payment.getPaymentMethod());

        dto.setPaymentStatus(
                payment.getPaymentStatus().name());

        dto.setPaymentGateway(
                payment.getPaymentGateway());

        dto.setGatewayTransactionId(
                payment.getGatewayTransactionId());

        dto.setTransactionReference(
                payment.getTransactionReference());

        dto.setRemarks(payment.getRemarks());

        dto.setPaymentDate(
                payment.getPaymentDate());

        return dto;

    }

    /*
    ============================================================
            GENERATE TRANSACTION REFERENCE
    ============================================================

    Example

    TXN-20260727124530

    Later we can improve this to use

    UUID

    Database Sequence

    Payment Gateway Reference

    etc.
    ============================================================
    */

    private String generateTransactionReference() {

        return "TXN-"
                + System.currentTimeMillis();

    }

}






