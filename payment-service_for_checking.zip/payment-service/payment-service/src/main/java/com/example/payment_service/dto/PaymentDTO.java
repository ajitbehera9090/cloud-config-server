package com.example.payment_service.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PaymentDTO {

    private Long paymentId;

    @NotNull(message = "Customer Id is required.")
    private Long customerId;

    @NotNull(message = "Policy Id is required.")
    private Long policyId;

    @NotNull(message = "Payment amount is required.")
    @Positive(message = "Amount must be greater than zero.")
    @DecimalMin(value = "1.0", message = "Minimum payment amount should be at least 1.")
    private BigDecimal amount;

    @NotBlank(message = "Payment method is required.")
    private String paymentMethod;

    private String paymentStatus;

    private String paymentGateway;

    private String gatewayTransactionId;

    private String transactionReference;

    private String remarks;

    private LocalDateTime paymentDate;

}