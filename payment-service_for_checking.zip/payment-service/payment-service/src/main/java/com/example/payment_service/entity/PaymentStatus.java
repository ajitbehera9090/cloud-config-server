package com.example.payment_service.entity;

public enum PaymentStatus {

    CREATED,

    PENDING,

    PROCESSING,

    SUCCESS,

    FAILED,

    CANCELLED,

    REFUNDED

}