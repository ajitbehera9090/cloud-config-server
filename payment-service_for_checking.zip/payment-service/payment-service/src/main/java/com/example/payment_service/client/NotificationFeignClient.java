package com.example.payment_service.client;


import com.example.payment_service.dto.NotificationDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "notification-service")
public interface NotificationFeignClient {

    @PostMapping("/notifications/send")
    String sendNotification(@RequestBody NotificationDTO notificationDTO);

}