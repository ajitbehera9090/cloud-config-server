package com.example.payment_service.service;



import com.example.payment_service.dto.PaymentDTO;

import java.util.List;

public interface PaymentService {

    PaymentDTO makePayment(PaymentDTO paymentDTO);

    PaymentDTO getPaymentById(Long paymentId);

    List<PaymentDTO> getAllPayments();

    List<PaymentDTO> getPaymentsByCustomerId(Long customerId);

    List<PaymentDTO> getPaymentsByPolicyId(Long policyId);

    List<PaymentDTO> getPaymentsByStatus(String paymentStatus);

    PaymentDTO updatePayment(Long paymentId,
                             PaymentDTO paymentDTO);

    void deletePayment(Long paymentId);

}