package com.example.payment_service.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class NotificationDTO {

    private Long customerId;
    private String recipientEmail;
    private String subject;
    private String message;

}