package com.example.payment_service.repository;


import com.example.payment_service.entity.Payment;
import com.example.payment_service.entity.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface PaymentRepository
        extends JpaRepository<Payment, Long> {

    Optional<Payment> findByTransactionReference(String transactionReference);

    List<Payment> findByCustomerId(Long customerId);

    List<Payment> findByPolicyId(Long policyId);

    List<Payment> findByPaymentStatus(PaymentStatus paymentStatus);

    /*
        JPQL Example

        We will discuss JPQL in detail later.
     */
    @Query("""
            SELECT p
            FROM Payment p
            WHERE p.paymentStatus='SUCCESS'
            """)
    List<Payment> findSuccessfulPayments();

}