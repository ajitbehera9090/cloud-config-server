package com.example.payment_service.exception;

public class PaymentAlreadyCompletedException extends RuntimeException {

    public PaymentAlreadyCompletedException(String message) {
        super(message);
    }

}