package com.example.payment_service.dto;

import lombok.*;

import java.math.BigDecimal;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class PolicyDTO {

    private Long policyId;
    private String policyNumber;
    private String policyName;
    private BigDecimal premiumAmount;
    private String policyStatus;

}