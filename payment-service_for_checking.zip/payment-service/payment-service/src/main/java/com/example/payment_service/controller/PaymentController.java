package com.example.payment_service.controller;



import com.example.payment_service.dto.PaymentDTO;
import com.example.payment_service.service.PaymentService;
import jakarta.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    private static final Logger logger =
            LoggerFactory.getLogger(PaymentController.class);

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    /*
     ---------------------------------------------------------
     Make Payment
     ---------------------------------------------------------
     */

    @PostMapping
    public ResponseEntity<PaymentDTO> makePayment(
            @Valid @RequestBody PaymentDTO paymentDTO) {

        logger.info("Received request to make payment.");

        PaymentDTO savedPayment =
                paymentService.makePayment(paymentDTO);

        logger.info("Payment completed successfully.");

        return new ResponseEntity<>(
                savedPayment,
                HttpStatus.CREATED);

    }

    /*
     ---------------------------------------------------------
     Get Payment By Id
     ---------------------------------------------------------
     */

    @GetMapping("/{paymentId}")
    public ResponseEntity<PaymentDTO> getPaymentById(
            @PathVariable Long paymentId) {

        logger.info("Fetching payment with Id : {}", paymentId);

        PaymentDTO payment =
                paymentService.getPaymentById(paymentId);

        return ResponseEntity.ok(payment);

    }

    /*
     ---------------------------------------------------------
     Get All Payments
     ---------------------------------------------------------
     */

    @GetMapping
    public ResponseEntity<List<PaymentDTO>> getAllPayments() {

        logger.info("Fetching all payments.");

        return ResponseEntity.ok(
                paymentService.getAllPayments());

    }

    /*
     ---------------------------------------------------------
     Get Payments By Customer Id
     ---------------------------------------------------------
     */

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<PaymentDTO>>
    getPaymentsByCustomerId(
            @PathVariable Long customerId) {

        logger.info("Fetching payments of customer {}",
                customerId);

        return ResponseEntity.ok(
                paymentService.getPaymentsByCustomerId(
                        customerId));

    }

    /*
     ---------------------------------------------------------
     Get Payments By Policy Id
     ---------------------------------------------------------
     */

    @GetMapping("/policy/{policyId}")
    public ResponseEntity<List<PaymentDTO>>
    getPaymentsByPolicyId(
            @PathVariable Long policyId) {

        logger.info("Fetching payments of policy {}",
                policyId);

        return ResponseEntity.ok(
                paymentService.getPaymentsByPolicyId(
                        policyId));

    }

    /*
     ---------------------------------------------------------
     Get Payments By Status
     ---------------------------------------------------------
     */

    @GetMapping("/status/{paymentStatus}")
    public ResponseEntity<List<PaymentDTO>>
    getPaymentsByStatus(
            @PathVariable String paymentStatus) {

        logger.info("Fetching payments with status {}",
                paymentStatus);

        return ResponseEntity.ok(
                paymentService.getPaymentsByStatus(
                        paymentStatus));

    }

    /*
     ---------------------------------------------------------
     Update Payment
     ---------------------------------------------------------
     */

    @PutMapping("/{paymentId}")
    public ResponseEntity<PaymentDTO> updatePayment(

            @PathVariable Long paymentId,

            @Valid
            @RequestBody
            PaymentDTO paymentDTO) {

        logger.info("Updating payment {}",
                paymentId);

        return ResponseEntity.ok(

                paymentService.updatePayment(
                        paymentId,
                        paymentDTO));

    }

    /*
     ---------------------------------------------------------
     Delete Payment
     ---------------------------------------------------------
     */

    @DeleteMapping("/{paymentId}")
    public ResponseEntity<String> deletePayment(
            @PathVariable Long paymentId) {

        logger.info("Deleting payment {}",
                paymentId);

        paymentService.deletePayment(paymentId);

        return ResponseEntity.ok(
                "Payment deleted successfully.");

    }

}